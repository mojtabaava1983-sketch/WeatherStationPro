# M09 — Reporting & Export

Official M09 of WeatherStation Pro.

## Responsibility

M09 converts persisted WeatherStation data into user-facing reports and
export files.

M09 owns:
- report definitions;
- historical/current weather reports;
- forecast reports;
- city reports;
- summary reports;
- CSV export;
- Excel-compatible XLSX export;
- PDF-ready report specifications;
- date/city/source filtering;
- report metadata.

M09 does NOT:
- fetch APIs (M03);
- schedule collection (M04);
- perform core analysis (M05);
- calculate forecasts (M06);
- calculate sunrise/sunset (M07);
- manage Access UI (M08);
- perform backup/recovery (M10).

## Design

M09 is provider-independent and reads the database through a repository/query
boundary. Output generation is separated from report selection.

The module is intentionally extensible so M08 can later call it without
duplicating reporting logic.
