# M09 Smoke Test

- [ ] reporting package imports.
- [ ] report catalog loads.
- [ ] current weather report builds.
- [ ] city filtering works.
- [ ] source filtering works.
- [ ] time filtering works.
- [ ] CSV export writes UTF-8 CSV.
- [ ] XLSX exporter reports a clear dependency error if openpyxl is absent.
- [ ] no API calls are performed by M09.
- [ ] no API secrets are stored by M09.
