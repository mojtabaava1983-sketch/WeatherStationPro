Attribute VB_Name = "modM09UIBuilder"
Option Compare Database
Option Explicit

' M09 Access Reports UI Builder
' Prerequisites:
'   M09_CURRENT_WEATHER
'   M09_WEATHER_HISTORY
'   M09_FORECAST
'   M09_SUN_TIMES
' already exist and run successfully.
'
' Import this module once, compile, then run:
'   M09_BuildReportsUI
' from the VBA Immediate Window.

Public Const M09_FORM As String = "frmM09Reports"
Public Const M09_Q_CURRENT As String = "M09_CURRENT_WEATHER"
Public Const M09_Q_HISTORY As String = "M09_WEATHER_HISTORY"
Public Const M09_Q_FORECAST As String = "M09_FORECAST"
Public Const M09_Q_SUN As String = "M09_SUN_TIMES"

Public Function M09_BuildReportsUI() As Boolean
    On Error GoTo EH

    If Not M09_QueryExists(M09_Q_CURRENT) Then Err.Raise vbObjectError + 9001, , "Missing query: " & M09_Q_CURRENT
    If Not M09_QueryExists(M09_Q_HISTORY) Then Err.Raise vbObjectError + 9002, , "Missing query: " & M09_Q_HISTORY
    If Not M09_QueryExists(M09_Q_FORECAST) Then Err.Raise vbObjectError + 9003, , "Missing query: " & M09_Q_FORECAST
    If Not M09_QueryExists(M09_Q_SUN) Then Err.Raise vbObjectError + 9004, , "Missing query: " & M09_Q_SUN

    M09_CloseIfOpen M09_FORM
    If M09_FormExists(M09_FORM) Then DoCmd.DeleteObject acForm, M09_FORM

    M09_CreateReportsForm
    M09_ConnectM08EntryPoint

    M09_BuildReportsUI = True
    MsgBox "M09 Reports UI created and M08 entry point connected.", vbInformation, "WeatherStation Pro - M09"
    Exit Function
EH:
    M09_BuildReportsUI = False
    MsgBox "M09 UI build failed: " & Err.Number & " - " & Err.Description, vbCritical, "WeatherStation Pro - M09"
End Function

Private Sub M09_CreateReportsForm()
    Dim frm As Form
    Dim ctl As Control
    Dim generatedName As String

    Set frm = CreateForm
    frm.Caption = "WeatherStation Pro - M09 Reports"
    frm.Width = 9000
    frm.Section(acDetail).Height = 5200
    frm.NavigationButtons = False
    frm.RecordSelectors = False
    frm.ScrollBars = 0
    frm.DividingLines = False
    frm.AutoCenter = True

    Set ctl = CreateControl(frm.Name, acLabel, acDetail)
    ctl.Name = "lblM09Title"
    ctl.Caption = "M09 - Reporting & Export"
    ctl.Left = 600: ctl.Top = 400: ctl.Width = 7600: ctl.Height = 500
    ctl.FontSize = 18: ctl.FontBold = True

    Set ctl = CreateControl(frm.Name, acLabel, acDetail)
    ctl.Name = "lblM09Info"
    ctl.Caption = "Select a report to open the current M09 dataset."
    ctl.Left = 600: ctl.Top = 1050: ctl.Width = 7600: ctl.Height = 400

    M09_AddButton frm.Name, "cmdM09Current", "Current Weather", 900, 1750, 3200, 650, "=M09_OpenCurrentWeather()"
    M09_AddButton frm.Name, "cmdM09History", "Weather History", 4500, 1750, 3200, 650, "=M09_OpenWeatherHistory()"
    M09_AddButton frm.Name, "cmdM09Forecast", "Forecast", 900, 2700, 3200, 650, "=M09_OpenForecast()"
    M09_AddButton frm.Name, "cmdM09SunTimes", "Sunrise / Sunset", 4500, 2700, 3200, 650, "=M09_OpenSunTimes()"
    M09_AddButton frm.Name, "cmdM09Close", "Close", 2700, 3850, 3200, 650, "=M09_CloseReportsUI()"

    generatedName = frm.Name
    DoCmd.Save acForm, generatedName
    DoCmd.Close acForm, generatedName, acSaveYes

    If StrComp(generatedName, M09_FORM, vbTextCompare) <> 0 Then
        If M09_FormExists(M09_FORM) Then DoCmd.DeleteObject acForm, M09_FORM
        DoCmd.Rename M09_FORM, acForm, generatedName
    End If
End Sub

Private Sub M09_AddButton(ByVal formName As String, ByVal controlName As String, _
                          ByVal captionText As String, ByVal x As Long, ByVal y As Long, _
                          ByVal w As Long, ByVal h As Long, ByVal clickExpression As String)
    Dim btn As Control
    Set btn = CreateControl(formName, acCommandButton, acDetail)
    btn.Name = controlName
    btn.Caption = captionText
    btn.Left = x: btn.Top = y: btn.Width = w: btn.Height = h
    btn.FontSize = 11
    btn.OnClick = clickExpression
End Sub

Private Sub M09_ConnectM08EntryPoint()
    Dim frm As Form
    Dim ctl As Control
    Dim found As Boolean

    If Not M09_FormExists("frmReports") Then
        Err.Raise vbObjectError + 9020, , "M08 form frmReports was not found."
    End If

    M09_CloseIfOpen "frmReports"
    DoCmd.OpenForm "frmReports", acDesign, , , acFormEdit, acHidden
    Set frm = Forms("frmReports")

    For Each ctl In frm.Controls
        If ctl.ControlType = acCommandButton Then
            If StrComp(Nz(ctl.Caption, ""), "Open M09", vbTextCompare) = 0 Then
                ctl.OnClick = "=M09_OpenReportsUI()"
                found = True
                Exit For
            End If
        End If
    Next ctl

    If Not found Then
        DoCmd.Close acForm, "frmReports", acSaveNo
        Err.Raise vbObjectError + 9021, , "The 'Open M09' button was not found on frmReports."
    End If

    DoCmd.Save acForm, "frmReports"
    DoCmd.Close acForm, "frmReports", acSaveYes
End Sub

Public Function M09_OpenReportsUI() As Boolean
    On Error GoTo EH
    DoCmd.OpenForm M09_FORM
    M09_OpenReportsUI = True
    Exit Function
EH:
    MsgBox "Unable to open M09 Reports UI: " & Err.Number & " - " & Err.Description, vbExclamation, "M09"
End Function

Public Function M09_OpenCurrentWeather() As Boolean
    M09_OpenQuerySafe M09_Q_CURRENT
End Function

Public Function M09_OpenWeatherHistory() As Boolean
    M09_OpenQuerySafe M09_Q_HISTORY
End Function

Public Function M09_OpenForecast() As Boolean
    M09_OpenQuerySafe M09_Q_FORECAST
End Function

Public Function M09_OpenSunTimes() As Boolean
    M09_OpenQuerySafe M09_Q_SUN
End Function

Private Function M09_OpenQuerySafe(ByVal queryName As String) As Boolean
    On Error GoTo EH
    If Not M09_QueryExists(queryName) Then Err.Raise vbObjectError + 9030, , "Missing query: " & queryName
    DoCmd.OpenQuery queryName, acViewNormal
    M09_OpenQuerySafe = True
    Exit Function
EH:
    MsgBox "Unable to open query '" & queryName & "': " & Err.Number & " - " & Err.Description, vbExclamation, "M09"
End Function

Public Function M09_CloseReportsUI() As Boolean
    On Error Resume Next
    DoCmd.Close acForm, M09_FORM, acSaveNo
    M09_CloseReportsUI = True
End Function

Private Function M09_QueryExists(ByVal queryName As String) As Boolean
    Dim qdf As DAO.QueryDef
    On Error GoTo EH
    Set qdf = CurrentDb.QueryDefs(queryName)
    M09_QueryExists = True
    Exit Function
EH:
    M09_QueryExists = False
End Function

Private Function M09_FormExists(ByVal formName As String) As Boolean
    Dim ao As AccessObject
    On Error GoTo EH
    For Each ao In CurrentProject.AllForms
        If StrComp(ao.Name, formName, vbTextCompare) = 0 Then
            M09_FormExists = True
            Exit Function
        End If
    Next ao
    Exit Function
EH:
    M09_FormExists = False
End Function

Private Sub M09_CloseIfOpen(ByVal formName As String)
    On Error Resume Next
    If CurrentProject.AllForms(formName).IsLoaded Then DoCmd.Close acForm, formName, acSaveYes
    On Error GoTo 0
End Sub
