# M09 Integration

M08 can call M09 through ReportingService rather than implementing reporting
logic inside Access.

Recommended future flow:

M08 Access
   -> report request/filter
   -> M09 ReportingService
   -> repository/database
   -> ReportResult
   -> CSV/XLSX/PDF presentation

M09 does not own backup. M10 owns backup and recovery.

PDF generation is deliberately left behind an exporter boundary so a PDF
library can be selected during implementation without changing report
definitions.
