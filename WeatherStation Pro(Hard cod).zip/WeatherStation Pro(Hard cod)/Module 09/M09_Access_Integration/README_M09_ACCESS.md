# M09 Access Integration

This builder creates two saved Access QueryDefs:

- qryM09_CurrentWeather
- qryM09_WeatherHistory

It first verifies that the required tables `Cities` and `WeatherCurrent` exist.
The SQL is embedded from the two supplied M09 SQL files without changing their logic.

Run:
1. Import `modM09AccessIntegration.bas` into the M08 Access database.
2. Debug > Compile.
3. Run `BuildM09AccessQueries`.
4. Run `TestM09AccessQueries`.

If a required table is absent, the builder stops and reports the exact missing table.
