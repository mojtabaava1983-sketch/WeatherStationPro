Attribute VB_Name = "modM09AccessIntegration"
Option Compare Database
Option Explicit

' M09 -> Access integration
' Creates/refreshes the two M09 saved queries from the produced SQL files.
' The SQL is embedded exactly as supplied in M09_CURRENT_WEATHER.sql
' and M09_WEATHER_HISTORY.sql.

Public Sub BuildM09AccessQueries()
    On Error GoTo EH

    EnsureTableExists "Cities"
    EnsureTableExists "WeatherCurrent"

    CreateOrReplaceQuery "qryM09_CurrentWeather", _
        "SELECT " & _
        "C.CityID, C.CityName, C.Country, " & _
        "W.SourceID, W.ObservationUTC, W.ObservationUnix, " & _
        "W.Temperature, W.FeelsLike, W.Humidity, W.Pressure, " & _
        "W.WindSpeed, W.WindDirection, W.GustSpeed, W.CloudCover, " & _
        "W.Visibility, W.DewPoint, W.Rain, W.Snow, " & _
        "W.WeatherCode, W.DataQuality " & _
        "FROM WeatherCurrent AS W " & _
        "INNER JOIN Cities AS C ON W.CityID = C.CityID " & _
        "WHERE C.Enabled = 1;"

    CreateOrReplaceQuery "qryM09_WeatherHistory", _
        "SELECT " & _
        "C.CityID, C.CityName, C.Country, " & _
        "W.SourceID, W.ObservationUTC, W.ObservationUnix, " & _
        "W.Temperature, W.Humidity, W.Pressure, " & _
        "W.WindSpeed, W.Rain, W.Snow " & _
        "FROM WeatherCurrent AS W " & _
        "INNER JOIN Cities AS C ON W.CityID = C.CityID " & _
        "WHERE C.Enabled = 1 " & _
        "ORDER BY W.ObservationUnix DESC;"

    MsgBox "M09 Access queries created successfully.", vbInformation, "M09"
    Exit Sub

EH:
    MsgBox "M09 Access integration failed: " & Err.Number & _
           " - " & Err.Description, vbCritical, "M09"
End Sub

Private Sub CreateOrReplaceQuery(ByVal queryName As String, ByVal sqlText As String)
    Dim db As DAO.Database
    Dim qd As DAO.QueryDef

    Set db = CurrentDb

    On Error Resume Next
    db.QueryDefs.Delete queryName
    Err.Clear
    On Error GoTo 0

    Set qd = db.CreateQueryDef(queryName, sqlText)
    qd.Close

    Set qd = Nothing
    Set db = Nothing
End Sub

Private Sub EnsureTableExists(ByVal tableName As String)
    Dim db As DAO.Database
    Dim tdf As DAO.TableDef

    Set db = CurrentDb

    On Error Resume Next
    Set tdf = db.TableDefs(tableName)
    On Error GoTo 0

    If tdf Is Nothing Then
        Err.Raise vbObjectError + 1901, "modM09AccessIntegration", _
                  "Required table not found: " & tableName
    End If
End Sub

Public Sub TestM09AccessQueries()
    Dim db As DAO.Database
    Dim rs As DAO.Recordset

    Set db = CurrentDb

    Set rs = db.OpenRecordset("qryM09_CurrentWeather", dbOpenSnapshot)
    rs.Close
    Set rs = Nothing

    Set rs = db.OpenRecordset("qryM09_WeatherHistory", dbOpenSnapshot)
    rs.Close
    Set rs = Nothing

    Set db = Nothing

    MsgBox "M09 Access query smoke test: PASS", vbInformation, "M09"
End Sub
