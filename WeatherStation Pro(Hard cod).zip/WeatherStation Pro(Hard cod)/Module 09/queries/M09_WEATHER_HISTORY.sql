SELECT
    C.CityID,
    C.CityName,
    C.Country,
    W.SourceID,
    W.ObservationUTC,
    W.ObservationUnix,
    W.Temperature,
    W.Humidity,
    W.Pressure,
    W.WindSpeed,
    W.Rain,
    W.Snow
FROM WeatherCurrent AS W
INNER JOIN Cities AS C ON W.CityID = C.CityID
WHERE C.Enabled = 1
ORDER BY W.ObservationUnix DESC;
