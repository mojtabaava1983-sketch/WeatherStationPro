# M02-06 — Provider Settings

## Scope
Defines provider-level configuration without implementing provider clients.

## Included
- Provider identity and base URL.
- Environment-variable reference for API keys.
- Enable/disable state.
- Timeout.
- Retry count.
- Optional rate limit.

## Safety
The API key itself is never stored in this model. Only the environment
variable name is configured; M02-04 handles secret retrieval.

## Boundary
No HTTP requests, retry execution, provider mapping, or API-specific payload
logic is introduced here.
