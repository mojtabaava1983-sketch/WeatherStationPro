# WeatherStationPro — M02-02 Settings Storage

Module: M02 — Configuration & Setting
Pack: M02-02
Scope: configuration persistence abstraction.
