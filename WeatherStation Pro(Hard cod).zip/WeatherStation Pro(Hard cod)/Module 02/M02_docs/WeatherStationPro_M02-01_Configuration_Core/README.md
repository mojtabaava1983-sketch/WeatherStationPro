# WeatherStationPro — M02-01

Module: M02 — Configuration & Setting
Pack: M02-01
Status: Produced; ready for local verification.

Run:
    python -m pytest -q tests/test_configuration_core.py
