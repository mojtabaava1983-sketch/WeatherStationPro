# M02-09 — Fault Tolerance & Recovery

Module: M02 — Configuration & Setting

## Scope
Provides controlled recovery when configuration loading fails.

## Behavior
1. Attempt normal configuration loading.
2. If loading fails, invoke a caller-supplied safe fallback.
3. Return whether fallback was used.
4. Preserve a diagnostic error without exposing secret values.
5. If fallback also fails, raise a dedicated recovery error.

## Boundary
No provider requests, scheduling, secret logging, or database schema changes.
The final M02 integration layer decides which defaults are safe and how
recovered/degraded states are exposed.
