# M02-04 — Environment & Secrets

## Scope
Provides a controlled way to read environment variables and secrets.

## Rules
- Secrets are read from process environment.
- Missing required values produce a controlled error.
- Empty required values are rejected.
- Diagnostic output can use a masked representation.
- Secret values are never written by this component to files or logs.
- No `.env` parser is introduced here.
- No provider-specific names are hard-coded.
- No database schema changes.

Later M02 integration can map provider/API settings to this abstraction.
