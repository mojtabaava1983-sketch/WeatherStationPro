# M02-05 — Application Settings

## Scope
Defines application-level settings with explicit defaults and basic
self-validation.

## Included
- Application identity and environment.
- Timezone and language.
- Logging level.
- Application enabled state.
- Data retention setting.
- Serialization/deserialization.

## Boundary
This pack does not define Provider settings, secrets, HTTP behavior, or
persistent storage. It is the application-facing settings model that later
M02 integration will compose with the other configuration layers.
