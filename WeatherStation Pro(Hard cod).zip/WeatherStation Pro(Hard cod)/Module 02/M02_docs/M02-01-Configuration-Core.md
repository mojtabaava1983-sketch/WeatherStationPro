# M02-01 — Configuration Core

Module: M02 — Configuration & Setting

## Scope
Central configuration abstraction for WeatherStationPro.

## Included
- Setting definitions
- Default values
- Explicit overrides
- get/require operations
- Runtime set/update
- Secret masking
- Unit tests

## Not included
Persistent settings storage, environment parsing, provider/API settings,
HTTP integration, UI, or database schema changes. Those belong to later M02
packs.

## Rule
Later modules consume configuration through this abstraction instead of
embedding settings throughout the codebase.
