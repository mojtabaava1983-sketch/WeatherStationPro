# M02-03 — Configuration Validation

## Scope
Adds explicit validation for configuration definitions.

## Rules
- Required settings must not be missing or empty.
- Optional settings may be absent or None.
- Defaults are considered when a setting is absent.
- Validation returns structured issues.
- `validate_or_raise` provides a controlled exception for callers that need
  strict validation.

## Deliberately excluded
- Provider-specific rules.
- Environment/secrets loading.
- Runtime behavior.
- UI.
- Database schema changes.
