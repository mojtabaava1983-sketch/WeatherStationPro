# WeatherStationPro — M02-05 Application Settings

Module: M02 — Configuration & Setting
Pack: M02-05
