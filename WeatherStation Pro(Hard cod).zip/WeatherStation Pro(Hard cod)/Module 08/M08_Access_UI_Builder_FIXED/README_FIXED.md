# M08 Access UI Builder - Fixed

This is the corrected replacement for `modM08UIBuilder.bas`.

The fix addresses:
`You can't rename the database object 'Form1' while it's open.`

The temporary form is now saved and closed before `DoCmd.Rename`.

Use:
1. Import `modM08UIBuilder_FIXED.bas` into the clean M08 database.
2. Remove the old `modM08UIBuilder` module if it exists, to avoid duplicate procedure names.
3. Debug > Compile VBAProject.
4. Run `BuildM08UI`.
