Attribute VB_Name = "modM08UIBuilder"
Option Compare Database
Option Explicit

Public Sub BuildM08UI()
    DeleteM08Forms
    CreateMainNavigation
    CreateWeatherDashboard
    CreateCityManager
    CreateForecast
    CreateSunTimes
    CreateReports
    MsgBox "M08 UI created successfully.", vbInformation, "WeatherStation Pro"
End Sub

Public Sub DeleteM08Forms()
    Dim n As Variant
    For Each n In Array("frmMainNavigation", "frmWeatherDashboard", "frmCityManager", "frmForecast", "frmSunTimes", "frmReports")
        If FormExists(CStr(n)) Then DoCmd.DeleteObject acForm, CStr(n)
    Next n
End Sub

Private Function FormExists(ByVal formName As String) As Boolean
    On Error Resume Next
    Dim f As AccessObject
    Set f = CurrentProject.AllForms(formName)
    FormExists = (Err.Number = 0 And Not f Is Nothing)
    Err.Clear
    On Error GoTo 0
End Function

Private Function NewM08Form(ByVal formName As String, ByVal title As String) As Form
    Dim f As Form
    Dim tempName As String

    ' CreateForm opens a temporary form (usually Form1).
    ' Access cannot rename an open object, so save and close it first.
    Set f = CreateForm
    tempName = f.Name

    f.Caption = title
    f.Width = 11000
    f.Section(acDetail).Height = 7000

    DoCmd.Save acForm, tempName
    DoCmd.Close acForm, tempName, acSaveYes

    ' The saved object is now closed, so Rename is safe.
    DoCmd.Rename formName, acForm, tempName

    ' Reopen in design mode so controls can be added.
    DoCmd.OpenForm formName, acDesign, , , , acHidden
    Set NewM08Form = Forms(formName)
End Function

Private Sub AddLabel(ByVal formName As String, ByVal name As String, ByVal caption As String, _
                     ByVal x As Long, ByVal y As Long, ByVal w As Long, Optional ByVal h As Long = 350)
    Dim c As Control
    Set c = CreateControl(formName, acLabel, acDetail, , , x, y, w, h)
    c.Name = name
    c.Caption = caption
End Sub

Private Sub AddText(ByVal formName As String, ByVal name As String, _
                    ByVal x As Long, ByVal y As Long, ByVal w As Long, ByVal h As Long)
    Dim c As Control
    Set c = CreateControl(formName, acTextBox, acDetail, , , x, y, w, h)
    c.Name = name
    c.ControlSource = "="""""
End Sub

Private Sub AddButton(ByVal formName As String, ByVal name As String, ByVal caption As String, _
                      ByVal x As Long, ByVal y As Long, ByVal w As Long, ByVal expression As String)
    Dim c As Control
    Set c = CreateControl(formName, acCommandButton, acDetail, , , x, y, w, 450)
    c.Name = name
    c.Caption = caption
    c.OnClick = expression
End Sub

Private Sub CloseDesign(ByVal formName As String)
    DoCmd.Close acForm, formName, acSaveYes
End Sub

Private Sub CreateMainNavigation()
    Dim f As Form
    Set f = NewM08Form("frmMainNavigation", "WeatherStation Pro - Main Navigation")
    AddLabel f.Name, "lblTitle", "WeatherStation Pro", 600, 500, 9000, 500
    AddButton f.Name, "cmdDashboard", "Weather Dashboard", 800, 1400, 3500, "=M08_OpenForm(""frmWeatherDashboard"")"
    AddButton f.Name, "cmdCityManager", "City Manager", 4500, 1400, 2500, "=M08_OpenForm(""frmCityManager"")"
    AddButton f.Name, "cmdForecast", "Forecast", 800, 2100, 3500, "=M08_OpenForm(""frmForecast"")"
    AddButton f.Name, "cmdSunTimes", "Sunrise / Sunset", 4500, 2100, 2500, "=M08_OpenForm(""frmSunTimes"")"
    AddButton f.Name, "cmdReports", "Reports", 800, 2800, 3500, "=M08_OpenForm(""frmReports"")"
    AddButton f.Name, "cmdExit", "Exit", 4500, 2800, 2500, "=M08_ExitApplication()"
    CloseDesign f.Name
    SetStartupForm "frmMainNavigation"
End Sub

Private Sub WeatherCard(ByVal formName As String, ByVal caption As String, ByVal ctl As String, _
                        ByVal x As Long, ByVal y As Long)
    AddLabel formName, "lbl_" & ctl, caption, x, y, 1900, 300
    AddText formName, ctl, x, y + 300, 1900, 450
End Sub

Private Sub CreateWeatherDashboard()
    Dim f As Form
    Set f = NewM08Form("frmWeatherDashboard", "WeatherStation Pro - Weather Dashboard")
    AddLabel f.Name, "lblHeader", "WeatherStation Pro", 400, 300, 10000, 450
    AddLabel f.Name, "lblCity", "Selected City", 400, 900, 1800
    AddText f.Name, "txtCity", 2300, 850, 2800, 350
    AddLabel f.Name, "lblObservation", "Observation UTC", 5400, 900, 1700
    AddText f.Name, "txtObservationUTC", 7200, 850, 2500, 350
    AddLabel f.Name, "lblSource", "Source", 400, 1350, 900
    AddText f.Name, "txtSource", 1400, 1300, 3700, 350

    WeatherCard f.Name, "Temperature", "txtTemperature", 400, 1900
    WeatherCard f.Name, "Feels Like", "txtFeelsLike", 2700, 1900
    WeatherCard f.Name, "Humidity", "txtHumidity", 5000, 1900
    WeatherCard f.Name, "Pressure", "txtPressure", 7300, 1900
    WeatherCard f.Name, "Wind Speed", "txtWindSpeed", 400, 2800
    WeatherCard f.Name, "Wind Direction", "txtWindDirection", 2700, 2800
    WeatherCard f.Name, "Gust", "txtGust", 5000, 2800
    WeatherCard f.Name, "Cloud Cover", "txtCloudCover", 7300, 2800
    WeatherCard f.Name, "Visibility", "txtVisibility", 400, 3700
    WeatherCard f.Name, "Dew Point", "txtDewPoint", 2700, 3700
    WeatherCard f.Name, "Rain", "txtRain", 5000, 3700
    WeatherCard f.Name, "Snow", "txtSnow", 7300, 3700
    WeatherCard f.Name, "Weather Code", "txtWeatherCode", 400, 4600
    WeatherCard f.Name, "Data Quality", "txtDataQuality", 2700, 4600

    AddButton f.Name, "cmdRefresh", "Refresh", 5000, 4650, 1800, "=M08_RefreshDashboard()"
    AddButton f.Name, "cmdChangeCity", "Change City", 7000, 4650, 1800, "=M08_OpenForm(""frmCityManager"")"
    AddButton f.Name, "cmdForecast", "Open Forecast", 5000, 5250, 1800, "=M08_OpenForm(""frmForecast"")"
    AddButton f.Name, "cmdSunTimes", "Open Sunrise/Sunset", 7000, 5250, 2200, "=M08_OpenForm(""frmSunTimes"")"
    CloseDesign f.Name
End Sub

Private Sub CreateCityManager()
    Dim f As Form
    Set f = NewM08Form("frmCityManager", "WeatherStation Pro - City Manager")
    AddLabel f.Name, "lblTitle", "Enabled City Administration", 400, 300, 9000, 450
    AddLabel f.Name, "lblValidation", "Latitude: -90..90    Longitude: -180..180", 400, 850, 9000
    AddLabel f.Name, "lblCityList", "City List", 400, 1400, 1600
    AddText f.Name, "txtCityList", 2100, 1350, 5000, 2500
    AddButton f.Name, "cmdAdd", "Add", 400, 4300, 1500, "=M08_CityManagerMessage()"
    AddButton f.Name, "cmdEdit", "Edit", 2100, 4300, 1500, "=M08_CityManagerMessage()"
    AddButton f.Name, "cmdEnableDisable", "Enable / Disable", 3800, 4300, 2200, "=M08_CityManagerMessage()"
    AddButton f.Name, "cmdClose", "Close", 6500, 4300, 1500, "=M08_CloseCurrentForm()"
    CloseDesign f.Name
End Sub

Private Sub CreateForecast()
    Dim f As Form
    Set f = NewM08Form("frmForecast", "WeatherStation Pro - Forecast")
    AddLabel f.Name, "lblTitle", "Forecast", 500, 400, 9000, 500
    AddLabel f.Name, "lblInfo", "Presentation only. Forecast calculation belongs to M06.", 500, 1200, 9000, 500
    AddButton f.Name, "cmdClose", "Close", 500, 2000, 1800, "=M08_CloseCurrentForm()"
    CloseDesign f.Name
End Sub

Private Sub CreateSunTimes()
    Dim f As Form
    Set f = NewM08Form("frmSunTimes", "WeatherStation Pro - Sunrise / Sunset")
    AddLabel f.Name, "lblTitle", "Sunrise / Sunset", 500, 400, 9000, 500
    AddLabel f.Name, "lblInfo", "Presentation only. Astronomical calculation belongs to M07.", 500, 1200, 9000, 500
    AddButton f.Name, "cmdClose", "Close", 500, 2000, 1800, "=M08_CloseCurrentForm()"
    CloseDesign f.Name
End Sub

Private Sub CreateReports()
    Dim f As Form
    Set f = NewM08Form("frmReports", "WeatherStation Pro - Reports")
    AddLabel f.Name, "lblTitle", "Reports", 500, 400, 9000, 500
    AddLabel f.Name, "lblInfo", "Reports entry point. Report implementation belongs to M09.", 500, 1200, 9000, 500
    AddButton f.Name, "cmdOpenM09", "Open M09", 500, 2000, 1800, "=M08_M09EntryPoint()"
    AddButton f.Name, "cmdClose", "Close", 2600, 2000, 1800, "=M08_CloseCurrentForm()"
    CloseDesign f.Name
End Sub

Public Function M08_OpenForm(ByVal formName As String) As Boolean
    On Error GoTo EH
    DoCmd.OpenForm formName
    M08_OpenForm = True
    Exit Function
EH:
    MsgBox "Unable to open " & formName & ": " & Err.Description, vbExclamation, "M08"
    M08_OpenForm = False
End Function

Public Function M08_CloseCurrentForm() As Boolean
    On Error GoTo EH
    DoCmd.Close acForm, Screen.ActiveForm.Name, acSaveNo
    M08_CloseCurrentForm = True
    Exit Function
EH:
    M08_CloseCurrentForm = False
End Function

Public Function M08_ExitApplication() As Boolean
    DoCmd.Quit acQuitSaveAll
    M08_ExitApplication = True
End Function

Public Function M08_RefreshDashboard() As Boolean
    On Error GoTo EH
    If CurrentProject.AllForms("frmWeatherDashboard").IsLoaded Then
        Forms("frmWeatherDashboard").Recalc
        Forms("frmWeatherDashboard").Repaint
    End If
    M08_RefreshDashboard = True
    Exit Function
EH:
    M08_RefreshDashboard = False
End Function

Public Function M08_CityManagerMessage() As Boolean
    MsgBox "City Manager UI is ready. Data validation/persistence remains in the M01/M08 data layer.", vbInformation, "M08"
    M08_CityManagerMessage = True
End Function

Public Function M08_M09EntryPoint() As Boolean
    MsgBox "M09 Reports entry point.", vbInformation, "WeatherStation Pro"
    M08_M09EntryPoint = True
End Function

Private Sub SetStartupForm(ByVal formName As String)
    On Error Resume Next
    CurrentDb.Properties("StartupForm") = formName
    If Err.Number <> 0 Then
        Err.Clear
        Dim p As DAO.Property
        Set p = CurrentDb.CreateProperty("StartupForm", dbText, formName)
        CurrentDb.Properties.Append p
    End If
    On Error GoTo 0
End Sub
