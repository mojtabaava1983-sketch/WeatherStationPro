# M08 Final Build Manifest

## VBA
- modM08Constants.bas
- modM08Utilities.bas
- modM08Navigation.bas
- modM08Dashboard.bas
- modM08Startup.bas

## Queries
- qryM08_CityList
- qryM08_LatestWeatherByCity
- qryM08_ApiSources

## Forms
- frmMainNavigation
- frmWeatherDashboard
- frmCityManager
- frmForecast
- frmSunTimes
- frmReports

## Architecture status

M08 now contains the complete Access-side presentation responsibility.
There is no standalone Presentation Core module in the official project.

M09 remains Reporting & Export.
