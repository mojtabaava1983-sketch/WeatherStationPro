# M08 — Microsoft Access Interface (Final)

Official M08 of WeatherStation Pro.

## Architectural decision

The previously proposed standalone "Presentation Core" is NOT a separate
project module. Its presentation responsibilities are now part of M08.

Therefore M08 owns:
- Access navigation;
- dashboard presentation;
- current weather presentation;
- city administration UI;
- forecast presentation;
- sunrise/sunset presentation;
- Access queries;
- user-facing refresh/status handling.

M01–M07 remain unchanged.

## Boundary

M08 presents and manages user interaction. It does not:
- fetch weather APIs;
- calculate forecasts;
- calculate sunrise/sunset;
- perform analytical algorithms;
- store API secrets.

Those responsibilities remain in M03, M05, M06 and M07.

## Data flow

M01–M07 -> WeatherStation SQLite database -> M08 Access Interface.

A future Web/Desktop UI can be added later without changing M01–M07,
but no standalone Presentation Core is required by the current official
12-module architecture.

## ACCDB

This is an Access-ready source package. A real .accdb must be assembled on
Windows with Microsoft Access and a compatible SQLite ODBC driver.
