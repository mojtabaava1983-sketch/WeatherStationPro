# M08 Final Smoke Test

- [ ] Blank Access database opens.
- [ ] Startup form is frmMainNavigation.
- [ ] Dashboard opens.
- [ ] City selector lists enabled Cities.
- [ ] Latest weather query returns the newest row per city.
- [ ] NULL values display as —.
- [ ] Refresh button works.
- [ ] City validation rejects latitude outside -90..90.
- [ ] City validation rejects longitude outside -180..180.
- [ ] Forecast form opens without attempting forecast calculation.
- [ ] Sunrise/Sunset form opens without astronomical calculation.
- [ ] Reports button opens M09 entry point.
- [ ] No API key is stored in Access.
- [ ] No secret is printed by VBA.
- [ ] Access closes cleanly.
