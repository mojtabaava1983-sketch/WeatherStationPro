# M07 — Sunrise / Sunset Engine

M07 calculates astronomical daylight events from city coordinates.

## Responsibilities
- Sunrise UTC.
- Sunset UTC.
- Approximate solar noon UTC.
- Multi-day calculation.
- Coordinate validation.
- Polar day / polar night state.

## Method

The first implementation uses a NOAA-style solar-position approximation and
does not require an external API.

This is a deterministic astronomical calculation layer, not a weather forecast.

## Boundary

M01 Database
  ↓
M07 Sunrise / Sunset Engine
  ↓
M08 Weather Dashboard / Presentation

M07 does not call weather APIs and does not write to the database.

## Dependencies

Python standard library only.

## Test

```powershell
$env:PYTHONPATH = "$PWD\M07_TEST\src"
.\.venv\Scripts\python.exe -m pytest .\M07_TEST\tests\test_sunlight -q
```
