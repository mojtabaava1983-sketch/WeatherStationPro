# M04 — Scheduler

M04 is the scheduling/background execution layer.

Boundary:
M02 Configuration -> M04 Scheduler -> M03 Weather API Engine -> M01 Database Core

M04 only decides when callbacks run. It does not own API calls or database persistence.
Runtime dependencies: Python standard library only.

Test:
$env:PYTHONPATH = "$PWD\M04_TEST\src"
.\.venv\Scripts\python.exe -m pytest .\M04_TEST\tests\test_scheduler -q
