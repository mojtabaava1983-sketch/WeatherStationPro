# M05 — Data Analysis Engine

M05 is the pure analysis layer for normalized weather observations.

## Responsibilities
- Descriptive statistics: mean, median, min/max, population standard deviation.
- Missing-value handling.
- Quality filtering.
- Linear trend detection.
- Rolling means.
- Hourly aggregation.
- Quality scoring helpers.

## Boundary
M03 Weather API Engine
  ↓
M05 Data Analysis Engine
  ↓
M06 Forecast Engine

M05 does not call weather APIs and does not write to the database. It consumes
normalized observations and returns analysis objects.

## Dependencies
Python standard library only.

## Test
```powershell
$env:PYTHONPATH = "$PWD\M05_TEST\src"
.\.venv\Scripts\python.exe -m pytest .\M05_TEST\tests\test_data_analysis -q
```
