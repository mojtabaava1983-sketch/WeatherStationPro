# M06 — Forecast Engine (7–10 days)

M06 is the forecast layer of WeatherStation Pro.

## Responsibilities

- Produce 1–10 day forecasts from historical normalized observations.
- Provide a deterministic first-generation baseline.
- Produce forecast intervals and confidence values.
- Validate forecast ordering and intervals.
- Keep forecast logic independent from API and database implementations.

## Current method

`linear_trend_baseline`

This is intentionally a dependency-free baseline implementation. It is NOT
presented as a production meteorological numerical model. A future forecasting
provider/model can replace the estimator behind the same ForecastSeries API.

## Boundary

M05 Data Analysis Engine
        ↓
M06 Forecast Engine
        ↓
M07 Sunrise / Sunset Engine

M06 consumes historical numeric data and does not directly call APIs or write
to the database.

## Horizon

Supported horizon: 1 through 10 days.

The project target for M06 is 7–10 days.

## Dependencies

Python standard library only.

## Test

```powershell
$env:PYTHONPATH = "$PWD\M06_TEST\src"
.\.venv\Scripts\python.exe -m pytest .\M06_TEST\tests\test_forecast -q
```
