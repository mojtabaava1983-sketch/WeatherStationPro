
import sqlite3, pytest
from pathlib import Path
from database.database_manager import DatabaseManager
from database.validation import DatabaseValidator
from database.backup_manager import BackupManager
from database.repository import WeatherRepository, RepositoryError
from database.weather_service import WeatherService
from database.observation_mapper import ObservationMapper

SCHEMA=Path(__file__).resolve().parents[1]/"database"/"schema.sql"

def init_db(p):
    DatabaseManager(p).initialize([SCHEMA])

def seed(p):
    c=sqlite3.connect(p)
    c.execute("""INSERT INTO Cities
    (CityName,Country,Latitude,Longitude,TimeZoneID,CreatedUTC,CreatedUnix)
    VALUES (?,?,?,?,?,?,?)""",
    ("Test City","Testland",40,50,"UTC","2026-08-10T00:00:00+00:00",1786320000))
    c.execute("INSERT INTO ApiSources (SourceName,BaseURL) VALUES (?,?)",
              ("TestProvider","https://example.invalid"))
    c.commit(); c.close()

BASE={"CityID":1,"SourceID":1,
      "ObservationUTC":"2026-08-10T12:00:00+00:00",
      "ObservationUnix":1786363200,
      "CreatedUTC":"2026-08-10T12:00:01+00:00",
      "CreatedUnix":1786363201}

def test_01_schema_health(tmp_path):
    db=tmp_path/"w.db"; init_db(db)
    result=DatabaseValidator(db).validate()
    assert result["healthy"] is True

def test_02_missing_temperature_humidity_still_saves(tmp_path):
    db=tmp_path/"w.db"; init_db(db); seed(db)
    values={**BASE,"WindSpeed":5.5,"Pressure":1013.2}
    rid=WeatherService(WeatherRepository(db)).save_observation("WeatherCurrent",values)
    assert rid>0
    row=sqlite3.connect(db).execute(
      "SELECT Temperature,Humidity,WindSpeed,Pressure,ObservationUTC FROM WeatherCurrent"
    ).fetchone()
    assert row==(None,None,5.5,1013.2,BASE["ObservationUTC"])

def test_03_only_temperature(tmp_path):
    db=tmp_path/"w.db"; init_db(db); seed(db)
    assert WeatherService(WeatherRepository(db)).save_observation(
      "WeatherCurrent",{**BASE,"Temperature":22.0})>0

def test_04_only_humidity(tmp_path):
    db=tmp_path/"w.db"; init_db(db); seed(db)
    assert WeatherService(WeatherRepository(db)).save_observation(
      "WeatherCurrent",{**BASE,"Humidity":61.0})>0

def test_05_windspeed_missing(tmp_path):
    db=tmp_path/"w.db"; init_db(db); seed(db)
    assert WeatherService(WeatherRepository(db)).save_observation(
      "WeatherCurrent",{**BASE,"Temperature":22.0,"Humidity":60.0})>0

def test_06_other_optional_fields_missing(tmp_path):
    db=tmp_path/"w.db"; init_db(db); seed(db)
    assert WeatherService(WeatherRepository(db)).save_observation(
      "WeatherCurrent",{**BASE,"Pressure":1012.0})>0

def test_07_empty_observation_rejected(tmp_path):
    db=tmp_path/"w.db"; init_db(db); seed(db)
    with pytest.raises(RepositoryError):
        WeatherService(WeatherRepository(db)).save_observation("WeatherCurrent",{})

def test_08_mapper_keeps_provider_extra():
    x=ObservationMapper.map({"temp":23,"humidity":58,"provider_extra":"kept"})
    assert x.extras["provider_extra"]=="kept"

def test_09_backup_restore(tmp_path):
    db=tmp_path/"w.db"; init_db(db)
    manager=BackupManager(db,tmp_path/"backups")
    backup=manager.create_backup()
    db.unlink()
    manager.restore(backup)
    assert DatabaseValidator(db).validate()["healthy"] is True

def test_10_schema_required_weather_columns_are_nullable(tmp_path):
    db=tmp_path/"w.db"; init_db(db)
    c=sqlite3.connect(db)
    info={r[1]:(r[3],r[4]) for r in c.execute("PRAGMA table_info(WeatherCurrent)")}
    c.close()
    assert info["Temperature"][0]==0
    assert info["Humidity"][0]==0
    assert info["WindSpeed"][0]==0
