import sqlite3
from pathlib import Path

from database.database_manager import DatabaseManager
from database.validation import DatabaseValidator
from database.backup_manager import BackupManager
from database.repository import WeatherRepository
from database.city_repository import CityRepository
from database.weather_service import WeatherService
from database.observation_mapper import ObservationMapper
from database.migration import MigrationManager

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / "database" / "schema.sql"

def init_db(path: Path):
    DatabaseManager(path).initialize([SCHEMA])

def seed_city_source(path: Path):
    c = sqlite3.connect(path)
    c.execute("""INSERT INTO Cities
        (CityName, Country, Latitude, Longitude, TimeZoneID, CreatedUTC, CreatedUnix)
        VALUES (?,?,?,?,?,?,?)""",
        ("Test City", "Testland", 40.0, 50.0, "UTC", "2026-08-10T00:00:00+00:00", 1786320000))
    c.execute("""INSERT INTO ApiSources
        (SourceName, BaseURL) VALUES (?,?)""",
        ("TestProvider", "https://example.invalid/api"))
    c.commit()
    c.close()

def test_full_schema_initializes_and_is_healthy(tmp_path):
    db = tmp_path / "weather.db"
    init_db(db)
    result = DatabaseValidator(db).validate()
    assert result["healthy"] is True
    required = {"DatabaseInfo","Cities","ApiSources","WeatherCurrent",
                "WeatherForecast","SunData","MoonData","AirQuality",
                "Settings","ImportStatus"}
    assert required.issubset(set(result["tables"]))

def test_city_and_observation_flow(tmp_path):
    db = tmp_path / "weather.db"
    init_db(db)
    seed_city_source(db)

    city = CityRepository(db).list_cities("Cities", "CityName")
    assert city[0]["CityName"] == "Test City"

    repo = WeatherRepository(db)
    service = WeatherService(repo)
    row_id = service.save_observation("WeatherCurrent", {
        "CityID": city[0]["CityID"],
        "SourceID": 1,
        "ObservationUTC": "2026-08-10T12:00:00+00:00",
        "ObservationUnix": 1786363200,
        "Temperature": 24.5,
        "Humidity": 60.0,
        "WindSpeed": None,
        "CreatedUTC": "2026-08-10T12:00:00+00:00",
        "CreatedUnix": 1786363200,
    })
    assert row_id > 0
    assert repo.count_rows("WeatherCurrent") == 1

def test_missing_optional_wind_does_not_block(tmp_path):
    db = tmp_path / "weather.db"
    init_db(db)
    seed_city_source(db)
    city_id = 1
    WeatherService(WeatherRepository(db)).save_observation(
        "WeatherCurrent",
        {
            "CityID": city_id, "SourceID": 1,
            "ObservationUTC": "2026-08-10T13:00:00+00:00",
            "ObservationUnix": 1786366800,
            "Temperature": 25.0, "Humidity": 62.0,
            "CreatedUTC": "2026-08-10T13:00:00+00:00",
            "CreatedUnix": 1786366800,
        },
    )
    assert WeatherRepository(db).count_rows("WeatherCurrent") == 1

def test_temperature_or_humidity_missing_is_rejected(tmp_path):
    db = tmp_path / "weather.db"
    init_db(db)
    seed_city_source(db)
    service = WeatherService(WeatherRepository(db))
    try:
        service.save_observation("WeatherCurrent", {
            "CityID": 1, "SourceID": 1,
            "ObservationUTC": "2026-08-10T14:00:00+00:00",
            "ObservationUnix": 1786370400,
            "Temperature": None, "Humidity": 60.0,
            "CreatedUTC": "2026-08-10T14:00:00+00:00",
            "CreatedUnix": 1786370400,
        })
    except Exception:
        pass
    else:
        raise AssertionError("Missing Temperature must be rejected")

def test_mapper_preserves_unknown_provider_fields():
    obs = ObservationMapper.map({
        "temp": 23.0, "humidity": 58.0, "windSpeed": None,
        "provider_extra": "kept"
    })
    assert ObservationMapper.required_fields_present(obs)
    assert obs.extras["provider_extra"] == "kept"

def test_backup_and_restore(tmp_path):
    db = tmp_path / "weather.db"
    init_db(db)
    backup_dir = tmp_path / "backups"
    manager = BackupManager(db, backup_dir)
    backup = manager.create_backup()
    assert backup.exists()
    db.unlink()
    manager.restore(backup)
    assert DatabaseValidator(db).validate()["healthy"] is True

def test_migration_metadata_is_available(tmp_path):
    db = tmp_path / "weather.db"
    manager = MigrationManager(db)
    manager.ensure_metadata()
    assert manager.current_version() == 0
