# M12 Smoke Test

- [ ] release package imports.
- [ ] version metadata loads.
- [ ] default manifest contains M01–M12.
- [ ] manifest validation passes.
- [ ] duplicate module IDs are detected.
- [ ] release ZIP can be built.
- [ ] SHA-256 checksum can be generated.
- [ ] installer layout is documented.
- [ ] upgrade preserves database/configuration.
- [ ] rollback procedure is documented.
- [ ] M12 does not modify M01–M11 business logic.
