# M12 Release Procedure

1. Verify all module packages are present.
2. Assemble the application source tree.
3. Validate `DEFAULT_MANIFEST`.
4. Run the complete test suite.
5. Build the release ZIP.
6. Generate SHA-256 checksum.
7. Archive the release artifact.
8. Record version and release channel.

For a production Windows installer, select and configure the installer
technology separately. The M12 release contract remains stable regardless of
that tooling choice.
