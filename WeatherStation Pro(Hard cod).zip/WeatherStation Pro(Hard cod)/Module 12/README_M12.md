# M12 — Installer & Release

Official M12 of WeatherStation Pro.

## Responsibility

M12 owns packaging and release preparation for the complete application.

M12 provides:
- release manifest;
- version metadata;
- package assembly;
- checksum generation;
- release validation;
- install layout specification;
- upgrade rules;
- rollback guidance.

M12 does NOT implement application business logic.

## Release principle

M12 packages already-produced modules. It must not silently modify M01–M11.

The release process is therefore:

M01–M11
   -> release manifest
   -> validation
   -> package
   -> checksums
   -> release artifact

A production installer executable can later be generated with an installer
technology selected for the deployment environment. This module deliberately
keeps installer-specific implementation behind a release boundary.
