# M11 Smoke Test

- [ ] Plugin package imports.
- [ ] Valid plugin registers.
- [ ] Duplicate plugin ID is rejected.
- [ ] Incompatible API version is rejected.
- [ ] Plugin lifecycle initializes.
- [ ] Plugin metadata is available without executing business logic.
- [ ] Discovery rejects a module without create_plugin().
- [ ] Discovery rejects an invalid factory result.
- [ ] Plugins can be stopped and shut down in reverse registration order.
- [ ] M11 does not require modification of M01–M10.
