# M11 — Plugin System

Official M11 of WeatherStation Pro.

## Responsibility

M11 provides a controlled extension mechanism for the application.

The plugin system is designed so future capabilities can be added without
modifying M01–M10 core modules.

Initial plugin contract:
- unique plugin id;
- plugin name/version;
- compatibility declaration;
- explicit capabilities;
- lifecycle hooks;
- safe metadata;
- optional provider/feature implementation.

## Security boundary

Plugins are trusted application extensions, not arbitrary untrusted code.
The registry rejects duplicate IDs and incompatible plugins.

M11 does not itself implement weather providers, forecasts or reports.
Those remain M03, M06 and M09 responsibilities.

## Future use

A future M03 weather provider can be packaged as a plugin without changing the
M03 core contract, provided it implements the relevant provider interface.
