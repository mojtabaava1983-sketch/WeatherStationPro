# M11 Plugin Contract

A plugin must provide:

```python
def create_plugin() -> Plugin:
    return MyPlugin()
```

and implement:

```text
Plugin.info
Plugin.initialize(context)
Plugin.start()
Plugin.stop()
Plugin.shutdown()
```

The plugin declares:
- plugin_id
- name
- version
- api_version
- capabilities

## Compatibility

The initial M11 API version is `1`.

A plugin whose declared API version does not match the registry API version is
rejected.

## Provider extension

A future M03 provider plugin can declare a capability such as:

`weather.provider`

The actual provider protocol remains owned by M03. M11 supplies discovery
and lifecycle; it does not replace M03.
