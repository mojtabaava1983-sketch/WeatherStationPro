# M03 — Weather API Engine
Provider-independent HTTP/API layer between M02 configuration and M01 persistence.

Design:
- Python 3.14 compatible
- dependency-free runtime using urllib
- bounded retries with exponential backoff
- provider adapter contract
- normalized observation model
- no direct database writes
- tests use mocks and do not require internet

Integration boundary:
M02 -> M03 Weather API Engine -> normalized observation -> M01 persistence.

Test:
python -m pytest .\tests\test_weather_api -q
