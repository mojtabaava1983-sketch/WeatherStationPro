# M13 Runtime Acceptance Test

1. `python run.py --city Baku`
   Expected: `RUNTIME FETCH: PASS`.
2. `python run_gui.py`
   Expected: GUI opens and Fetch Now succeeds.
3. Run the fetch three times.
   Expected: stored observation count increases.
4. `python run.py --city Baku --forecast`
   Expected: seven forecast rows.
5. Verify `database/weatherstation_m13.sqlite3` and table `m13_observations`.
6. Run the existing 99-test regression separately.
   M13 must not change the existing baseline.
