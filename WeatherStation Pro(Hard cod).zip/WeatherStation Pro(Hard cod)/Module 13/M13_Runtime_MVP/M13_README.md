# WeatherStation Pro M13 Runtime MVP

Flow: Live Provider -> SQLite -> Baseline Forecast -> GUI.

Run from this directory:
`python run.py --city Baku`
`python run_gui.py`

After at least 3 real observations:
`python run.py --city Baku --forecast`

Storage is additive in `database/weatherstation_m13.sqlite3` and uses
the `m13_observations` table, so existing project tables are not changed.

The first provider is Open-Meteo. Its public documentation describes the
Geocoding endpoint and Forecast endpoint used by M13. The free API is
available without an API key for non-commercial use.

M13 baseline forecast is deliberately conservative: it needs at least
3 collected observations and is not a replacement for a provider forecast.

Next phase after M13 RAT PASS: connect M13 storage to the project's main
M01/M08 schema, connect the existing scheduler, finalize dashboard, then
build the EXE.
