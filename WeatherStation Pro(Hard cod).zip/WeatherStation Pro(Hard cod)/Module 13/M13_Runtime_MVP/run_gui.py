from pathlib import Path
import threading
import tkinter as tk
from tkinter import ttk, messagebox
from m13_runtime.app import RuntimeApp, RuntimeConfig

ROOT = Path(__file__).resolve().parent
DB = ROOT/"database"/"weatherstation_m13.sqlite3"

class App:
    def __init__(self, root):
        self.root=root
        root.title("WeatherStation Pro - M13 Runtime")
        root.geometry("760x560")
        self.city=tk.StringVar(value="Baku")
        self.status=tk.StringVar(value="Ready")
        self.app=RuntimeApp(RuntimeConfig(ROOT,DB,"Baku"))
        self.vars={k:tk.StringVar(value="-") for k in
                   ("city","observed","temperature","humidity","wind","count")}
        self.text=None
        self.build()

    def build(self):
        f=ttk.Frame(self.root,padding=16); f.pack(fill="both",expand=True)
        ttk.Label(f,text="WeatherStation Pro",font=("Segoe UI",20,"bold")).pack(anchor="w")
        ttk.Label(f,text="M13 Runtime MVP").pack(anchor="w",pady=(0,12))
        b=ttk.Frame(f); b.pack(fill="x")
        ttk.Label(b,text="City:").pack(side="left")
        ttk.Entry(b,textvariable=self.city,width=24).pack(side="left",padx=8)
        ttk.Button(b,text="Fetch Now",command=self.fetch).pack(side="left",padx=4)
        ttk.Button(b,text="Baseline Forecast",command=self.forecast).pack(side="left",padx=4)
        ttk.Label(f,textvariable=self.status).pack(anchor="w",pady=10)
        g=ttk.Frame(f); g.pack(fill="x")
        for i,(title,key) in enumerate([("City","city"),("Observed","observed"),
            ("Temperature","temperature"),("Humidity","humidity"),("Wind","wind"),("Stored","count")]):
            ttk.Label(g,text=title+":").grid(row=i,column=0,sticky="w",pady=4)
            ttk.Label(g,textvariable=self.vars[key]).grid(row=i,column=1,sticky="w",pady=4)
        ttk.Label(f,text="7-Day Baseline Forecast").pack(anchor="w",pady=(16,4))
        self.text=tk.Text(f,height=14); self.text.pack(fill="both",expand=True)

    def fetch(self):
        self.status.set("Fetching live weather...")
        def work():
            try:
                self.app.config.city=self.city.get().strip() or "Baku"
                self.app.location=None
                r=self.app.fetch_once()
                self.root.after(0,lambda:self.show(r))
            except Exception as e:
                self.root.after(0,lambda:messagebox.showerror("M13 Runtime Error",str(e)))
                self.root.after(0,lambda:self.status.set("Fetch failed"))
        threading.Thread(target=work,daemon=True).start()

    def show(self,r):
        self.vars["city"].set(f"{r['city']}, {r['country']}")
        self.vars["observed"].set(r["observed_at"])
        self.vars["temperature"].set(f"{r['temperature']} °C")
        self.vars["humidity"].set(f"{r['humidity']} %")
        self.vars["wind"].set(f"{r['wind_speed']} km/h")
        self.vars["count"].set(str(r["count"]))
        self.status.set("Live fetch + SQLite storage: PASS")

    def forecast(self):
        try:
            rows=self.app.run_forecast(7)
            self.text.delete("1.0","end")
            for ts,v,lo,hi,c in rows:
                self.text.insert("end",f"{ts:%Y-%m-%d %H:%M} | {v:.2f} °C | {lo:.2f}..{hi:.2f} | {c:.2f}\n")
            self.status.set("Baseline forecast: PASS")
        except Exception as e:
            messagebox.showwarning("Forecast not ready",str(e))

if __name__=="__main__":
    root=tk.Tk(); App(root); root.mainloop()
