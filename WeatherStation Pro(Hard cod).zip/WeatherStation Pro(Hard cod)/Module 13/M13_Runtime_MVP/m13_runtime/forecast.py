from __future__ import annotations
from datetime import timedelta

def baseline_forecast(values, last_time, days=7):
    clean = [float(v) for v in values if v is not None]
    if len(clean) < 3:
        raise ValueError("At least 3 collected observations are required for baseline forecast.")
    try:
        from forecast import ForecastEngine
        series = ForecastEngine(default_horizon_days=days, minimum_history=3).forecast_7_day(
            "M13", "Temperature", clean, last_time
        )
        return [(p.timestamp, p.value, p.lower, p.upper, p.confidence) for p in series.points]
    except Exception:
        slope = (clean[-1] - clean[0]) / (len(clean)-1) if len(clean) > 1 else 0.0
        out = []
        for i in range(1, days+1):
            value = clean[-1] + slope*i
            spread = max(1.0, abs(value)*0.05)
            out.append((last_time + timedelta(days=i), round(value,2),
                        round(value-spread,2), round(value+spread,2),
                        max(0.10, 0.90-(i-1)*0.05)))
        return out
