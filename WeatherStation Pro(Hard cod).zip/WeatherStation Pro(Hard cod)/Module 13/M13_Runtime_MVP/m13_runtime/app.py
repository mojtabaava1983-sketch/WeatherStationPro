from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from .provider import OpenMeteoProvider
from .store import RuntimeStore
from .forecast import baseline_forecast

@dataclass
class RuntimeConfig:
    project_root: Path
    database_path: Path
    city: str = "Baku"
    interval_minutes: int = 60

class RuntimeApp:
    def __init__(self, config: RuntimeConfig):
        self.config = config
        self.provider = OpenMeteoProvider()
        self.store = RuntimeStore(config.database_path)
        self.location = None

    def fetch_once(self):
        self.location = self.location or self.provider.geocode(self.config.city)
        payload = self.provider.current(self.location)
        current = payload.get("current") or {}
        observed_at = str(current.get("time"))
        row_id = self.store.save(
            city=self.location.name, observed_at=observed_at,
            temperature=current.get("temperature_2m"),
            humidity=current.get("relative_humidity_2m"),
            wind_speed=current.get("wind_speed_10m"),
            weather_code=current.get("weather_code"),
            provider=self.provider.name,
            latitude=self.location.latitude, longitude=self.location.longitude,
        )
        return {
            "id": row_id, "city": self.location.name, "country": self.location.country,
            "timezone": self.location.timezone, "observed_at": observed_at,
            "temperature": current.get("temperature_2m"),
            "humidity": current.get("relative_humidity_2m"),
            "wind_speed": current.get("wind_speed_10m"),
            "count": self.store.count(self.location.name),
        }

    def run_forecast(self, days=7):
        self.location = self.location or self.provider.geocode(self.config.city)
        history = self.store.temperatures(self.location.name)
        if len(history) < 3:
            raise ValueError(f"Need at least 3 stored observations; currently {len(history)}.")
        return baseline_forecast([v for _,v in history], history[-1][0], days)
