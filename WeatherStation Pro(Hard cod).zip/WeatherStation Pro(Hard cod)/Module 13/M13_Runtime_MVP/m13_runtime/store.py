from __future__ import annotations
import sqlite3
from datetime import datetime
from pathlib import Path

class RuntimeStore:
    def __init__(self, database_path: str | Path):
        self.path = Path(database_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self):
        conn = sqlite3.connect(self.path, timeout=5)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA busy_timeout=5000")
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        return conn

    def _initialize(self):
        with self._connect() as conn:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS m13_observations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    city TEXT NOT NULL,
                    observed_at TEXT NOT NULL,
                    temperature REAL,
                    humidity REAL,
                    wind_speed REAL,
                    weather_code INTEGER,
                    provider TEXT NOT NULL,
                    latitude REAL NOT NULL,
                    longitude REAL NOT NULL
                )
            ''')
            conn.execute('CREATE INDEX IF NOT EXISTS idx_m13_obs_city_time '
                         'ON m13_observations(city, observed_at)')

    def save(self, **values) -> int:
        cols = ("city","observed_at","temperature","humidity","wind_speed",
                "weather_code","provider","latitude","longitude")
        with self._connect() as conn:
            cur = conn.execute(
                f'INSERT INTO m13_observations ({",".join(cols)}) '
                f'VALUES ({",".join("?" for _ in cols)})',
                tuple(values[c] for c in cols),
            )
            return int(cur.lastrowid)

    def temperatures(self, city: str, limit: int = 100):
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT observed_at, temperature FROM m13_observations "
                "WHERE city=? AND temperature IS NOT NULL "
                "ORDER BY observed_at DESC LIMIT ?", (city, limit)
            ).fetchall()
        return [(datetime.fromisoformat(r["observed_at"]), float(r["temperature"]))
                for r in reversed(rows)]

    def count(self, city: str | None = None) -> int:
        with self._connect() as conn:
            if city:
                return int(conn.execute(
                    "SELECT COUNT(*) FROM m13_observations WHERE city=?", (city,)
                ).fetchone()[0])
            return int(conn.execute("SELECT COUNT(*) FROM m13_observations").fetchone()[0])

    def health(self):
        with self._connect() as conn:
            integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
            fk = conn.execute("PRAGMA foreign_keys").fetchone()[0]
        return {"path": str(self.path), "integrity": integrity,
                "foreign_keys": bool(fk),
                "healthy": integrity == "ok" and bool(fk)}
