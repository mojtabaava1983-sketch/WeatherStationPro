from __future__ import annotations
import json
from dataclasses import dataclass
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

GEOCODING_URL = "https://geocoding-api.open-meteo.com/v1/search"
FORECAST_URL = "https://api.open-meteo.com/v1/forecast"

@dataclass(frozen=True)
class Location:
    name: str
    latitude: float
    longitude: float
    country: str = ""
    timezone: str = "UTC"

class ProviderError(RuntimeError):
    pass

class OpenMeteoProvider:
    name = "open-meteo"
    def __init__(self, timeout: float = 15.0):
        self.timeout = timeout

    def _get_json(self, base_url: str, params: dict) -> dict:
        url = base_url + "?" + urlencode(params)
        req = Request(url, headers={"User-Agent": "WeatherStationPro/0.1 M13"})
        try:
            with urlopen(req, timeout=self.timeout) as response:
                data = json.loads(response.read().decode("utf-8"))
        except (HTTPError, URLError, TimeoutError, OSError, ValueError) as exc:
            raise ProviderError(f"Provider request failed: {exc}") from exc
        if not isinstance(data, dict):
            raise ProviderError("Provider returned a non-object JSON response.")
        if data.get("error"):
            raise ProviderError(str(data.get("reason", "Provider returned an error.")))
        return data

    def geocode(self, city: str) -> Location:
        data = self._get_json(
            GEOCODING_URL,
            {"name": city, "count": 1, "language": "en", "format": "json"},
        )
        results = data.get("results") or []
        if not results:
            raise ProviderError(f"Location not found: {city}")
        item = results[0]
        return Location(
            name=str(item.get("name", city)),
            latitude=float(item["latitude"]),
            longitude=float(item["longitude"]),
            country=str(item.get("country", "")),
            timezone=str(item.get("timezone", "UTC")),
        )

    def current(self, location: Location) -> dict:
        return self._get_json(FORECAST_URL, {
            "latitude": location.latitude, "longitude": location.longitude,
            "current": "temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code",
            "timezone": "auto",
        })
