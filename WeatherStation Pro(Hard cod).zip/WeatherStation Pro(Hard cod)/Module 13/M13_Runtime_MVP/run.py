from pathlib import Path
import argparse
from m13_runtime.app import RuntimeApp, RuntimeConfig

def main():
    root = Path(__file__).resolve().parent
    p = argparse.ArgumentParser()
    p.add_argument("--city", default="Baku")
    p.add_argument("--db", default=str(root/"database"/"weatherstation_m13.sqlite3"))
    p.add_argument("--forecast", action="store_true")
    args = p.parse_args()
    app = RuntimeApp(RuntimeConfig(root, Path(args.db), args.city))
    if args.forecast:
        for ts,v,lo,hi,c in app.run_forecast(7):
            print(f"{ts.isoformat()} | {v:.2f} C | [{lo:.2f}, {hi:.2f}] | confidence={c:.2f}")
        return
    r = app.fetch_once()
    print("WEATHERSTATION PRO - M13 RUNTIME")
    print(f"CITY: {r['city']}, {r['country']}")
    print(f"OBSERVED: {r['observed_at']}")
    print(f"TEMPERATURE: {r['temperature']} C")
    print(f"HUMIDITY: {r['humidity']} %")
    print(f"WIND: {r['wind_speed']} km/h")
    print(f"STORED OBSERVATIONS: {r['count']}")
    print("RUNTIME FETCH: PASS")

if __name__ == "__main__":
    main()
