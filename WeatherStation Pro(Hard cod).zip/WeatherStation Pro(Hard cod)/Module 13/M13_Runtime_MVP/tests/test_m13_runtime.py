from pathlib import Path
import tempfile
from m13_runtime.store import RuntimeStore

def test_store_roundtrip():
    with tempfile.TemporaryDirectory() as td:
        s=RuntimeStore(Path(td)/"runtime.sqlite3")
        assert s.save(city="Baku",observed_at="2026-01-01T00:00:00",
            temperature=10,humidity=50,wind_speed=12,weather_code=1,
            provider="test",latitude=40.4,longitude=49.9)==1
        assert s.count("Baku")==1
        assert s.temperatures("Baku")[0][1]==10.0
        assert s.health()["healthy"]

def test_provider_endpoints():
    from m13_runtime.provider import GEOCODING_URL, FORECAST_URL
    assert GEOCODING_URL.startswith("https://")
    assert FORECAST_URL.startswith("https://")
