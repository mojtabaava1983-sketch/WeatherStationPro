# M10 — Backup & Recovery

Official M10 of WeatherStation Pro.

## Responsibility

M10 owns controlled backup, verification, retention and restoration of the
WeatherStation database.

M10 does NOT:
- collect weather data;
- run forecasts;
- generate reports;
- provide Access UI;
- manage application installation.

## Safety principles

1. Never overwrite an existing backup silently.
2. Verify a backup before declaring it valid.
3. Use SQLite backup API rather than raw file copying while the database may
   be active.
4. Keep metadata for each backup.
5. Restore only through an explicit operation.
6. Never delete the live database as part of a normal backup operation.
7. Retention is explicit and configurable.
