# M10 Smoke Test

- [ ] Backup package imports.
- [ ] Backup of a valid SQLite database succeeds.
- [ ] Backup integrity check returns ok.
- [ ] Existing backup is never silently overwritten.
- [ ] Missing database raises BackupError.
- [ ] Restore validates backup before restoring.
- [ ] Restore target is written through a temporary file.
- [ ] Restored database passes integrity_check.
- [ ] Retention keeps the configured number of newest backups.
- [ ] Manifest can be written and read.
- [ ] Normal backup never deletes the live database.
