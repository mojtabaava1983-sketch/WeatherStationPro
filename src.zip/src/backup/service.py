from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from .models import BackupResult, RestoreResult


class BackupError(RuntimeError):
    pass


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class BackupService:
    def __init__(self, backup_dir: str | Path):
        self.backup_dir = Path(backup_dir)
        self.backup_dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _check_integrity(path: Path) -> bool:
        if not path.exists():
            return False

        with sqlite3.connect(path, timeout=5.0) as conn:
            row = conn.execute(
                "PRAGMA integrity_check"
            ).fetchone()

        return bool(row and row[0] == "ok")

    def create_backup(
        self,
        database_path: str | Path,
    ) -> BackupResult:

        source = Path(database_path)

        if not source.exists():
            raise BackupError(
                f"Database not found: {source}"
            )

        stamp = datetime.now(timezone.utc).strftime(
            "%Y%m%dT%H%M%SZ"
        )

        destination = (
            self.backup_dir
            / f"{source.stem}_{stamp}.db"
        )

        if destination.exists():
            raise BackupError(
                f"Backup already exists: {destination}"
            )

        source_conn = None
        backup_conn = None

        try:
            source_conn = sqlite3.connect(
                source,
                timeout=5.0,
            )

            backup_conn = sqlite3.connect(
                destination,
                timeout=5.0,
            )

            source_conn.backup(backup_conn)
            backup_conn.commit()

        except sqlite3.Error as exc:
            destination.unlink(missing_ok=True)

            raise BackupError(
                f"Backup failed: {exc}"
            ) from exc

        finally:
            if backup_conn is not None:
                backup_conn.close()

            if source_conn is not None:
                source_conn.close()

        if not self._check_integrity(destination):
            destination.unlink(missing_ok=True)

            raise BackupError(
                f"Backup integrity check failed: {destination}"
            )

        return BackupResult(
            source=source,
            destination=destination,
            size_bytes=destination.stat().st_size,
            integrity_ok=True,
            created_utc=utc_now_iso(),
        )

    def restore_backup(
        self,
        backup_path: str | Path,
        destination: str | Path,
    ) -> RestoreResult:

        backup = Path(backup_path)
        target = Path(destination)

        if not backup.exists():
            raise BackupError(
                f"Backup not found: {backup}"
            )

        if not self._check_integrity(backup):
            raise BackupError(
                f"Backup is not healthy: {backup}"
            )

        if target.resolve() == backup.resolve():
            raise BackupError(
                "Restore destination must differ "
                "from backup."
            )

        target.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        try:
            target.unlink(missing_ok=True)
        except OSError as exc:
            raise BackupError(
                f"Cannot remove existing restore "
                f"destination: {target}"
            ) from exc

        source_conn = None
        target_conn = None

        try:
            source_conn = sqlite3.connect(
                backup,
                timeout=5.0,
            )

            target_conn = sqlite3.connect(
                target,
                timeout=5.0,
            )

            source_conn.backup(target_conn)
            target_conn.commit()

        except sqlite3.Error as exc:
            raise BackupError(
                f"Restore failed: {exc}"
            ) from exc

        finally:
            if target_conn is not None:
                target_conn.close()

            if source_conn is not None:
                source_conn.close()

        if not self._check_integrity(target):
            target.unlink(missing_ok=True)

            raise BackupError(
                "Restored database failed "
                "integrity check."
            )

        return RestoreResult(
            backup=backup,
            destination=target,
            integrity_ok=True,
        )