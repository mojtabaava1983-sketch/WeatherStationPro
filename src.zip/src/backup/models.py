from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path

@dataclass(frozen=True)
class BackupResult:
    source: Path
    destination: Path
    size_bytes: int
    integrity_ok: bool
    created_utc: str

@dataclass(frozen=True)
class RestoreResult:
    backup: Path
    destination: Path
    integrity_ok: bool
