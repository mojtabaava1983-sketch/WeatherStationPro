from __future__ import annotations
from pathlib import Path

class RetentionError(ValueError):
    pass

def prune_backups(
    backup_dir: str | Path,
    pattern: str = "*.db",
    keep: int = 7,
) -> list[Path]:
    if keep < 1:
        raise RetentionError("keep must be at least 1")

    directory = Path(backup_dir)
    backups = sorted(
        (p for p in directory.glob(pattern) if p.is_file()),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )

    removed = []
    for path in backups[keep:]:
        path.unlink()
        removed.append(path)
    return removed
