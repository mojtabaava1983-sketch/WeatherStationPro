from __future__ import annotations
from datetime import datetime, timezone
from typing import Any, Iterable, Mapping
from .catalog import get_report
from .models import ReportFilter, ReportResult

class ReportingError(RuntimeError):
    pass

class ReportingService:
    def build(
        self,
        report_id: str,
        rows: Iterable[Mapping[str, Any]],
        filters: ReportFilter | None = None,
    ) -> ReportResult:
        definition = get_report(report_id)
        selected = list(rows)

        if filters:
            selected = self._filter_rows(selected, filters)

        output = []
        for row in selected:
            output.append({
                column.name: row.get(column.source_key)
                for column in definition.columns
            })

        return ReportResult(
            report_id=definition.report_id,
            title=definition.title,
            columns=[c.name for c in definition.columns],
            rows=output,
            generated_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        )

    @staticmethod
    def _filter_rows(
        rows: list[Mapping[str, Any]],
        filters: ReportFilter,
    ) -> list[Mapping[str, Any]]:
        result = []
        for row in rows:
            if filters.city_id is not None and row.get("CityID") != filters.city_id:
                continue
            if filters.source_id is not None and row.get("SourceID") != filters.source_id:
                continue
            observation = row.get("ObservationUnix", row.get("ForecastUnix"))
            if filters.start_unix is not None and (
                observation is None or observation < filters.start_unix
            ):
                continue
            if filters.end_unix is not None and (
                observation is None or observation > filters.end_unix
            ):
                continue
            result.append(row)
        return result
