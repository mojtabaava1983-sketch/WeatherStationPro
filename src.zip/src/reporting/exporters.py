from __future__ import annotations
import csv
from pathlib import Path
from typing import Iterable, Mapping, Sequence

class ExportError(RuntimeError):
    pass

def export_csv(
    path: str | Path,
    columns: Sequence[str],
    rows: Iterable[Mapping[str, object]],
) -> Path:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        with destination.open("w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(columns), extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)
    except OSError as exc:
        raise ExportError(str(exc)) from exc
    return destination

def export_xlsx(
    path: str | Path,
    columns: Sequence[str],
    rows: Iterable[Mapping[str, object]],
) -> Path:
    try:
        from openpyxl import Workbook
    except ImportError as exc:
        raise ExportError(
            "XLSX export requires openpyxl. Install it before using export_xlsx()."
        ) from exc

    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)

    try:
        workbook = Workbook()
        sheet = workbook.active
        sheet.title = "Report"
        sheet.append(list(columns))
        for row in rows:
            sheet.append([row.get(column) for column in columns])
        workbook.save(destination)
    except OSError as exc:
        raise ExportError(str(exc)) from exc

    return destination
