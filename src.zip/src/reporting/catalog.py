from __future__ import annotations
from .models import ReportColumn, ReportDefinition

DEFAULT_REPORTS = (
    ReportDefinition(
        "current_weather",
        "Current Weather",
        (
            ReportColumn("City", "CityName"),
            ReportColumn("Observation UTC", "ObservationUTC"),
            ReportColumn("Temperature", "Temperature"),
            ReportColumn("Feels Like", "FeelsLike"),
            ReportColumn("Humidity", "Humidity"),
            ReportColumn("Pressure", "Pressure"),
            ReportColumn("Wind Speed", "WindSpeed"),
            ReportColumn("Cloud Cover", "CloudCover"),
            ReportColumn("Visibility", "Visibility"),
            ReportColumn("Data Quality", "DataQuality"),
        ),
    ),
    ReportDefinition(
        "weather_history",
        "Weather History",
        (
            ReportColumn("City", "CityName"),
            ReportColumn("Observation UTC", "ObservationUTC"),
            ReportColumn("Temperature", "Temperature"),
            ReportColumn("Humidity", "Humidity"),
            ReportColumn("Pressure", "Pressure"),
            ReportColumn("Wind Speed", "WindSpeed"),
            ReportColumn("Rain", "Rain"),
            ReportColumn("Snow", "Snow"),
        ),
    ),
    ReportDefinition(
        "forecast",
        "Forecast",
        (
            ReportColumn("City", "CityName"),
            ReportColumn("Forecast UTC", "ForecastUTC"),
            ReportColumn("Temperature", "Temperature"),
            ReportColumn("Precipitation Probability", "PrecipitationProbability"),
            ReportColumn("Weather Code", "WeatherCode"),
        ),
    ),
    ReportDefinition(
        "sun_times",
        "Sunrise / Sunset",
        (
            ReportColumn("City", "CityName"),
            ReportColumn("Date", "Date"),
            ReportColumn("Sunrise", "Sunrise"),
            ReportColumn("Sunset", "Sunset"),
            ReportColumn("Solar Noon", "SolarNoon"),
        ),
    ),
)

def get_report(report_id: str) -> ReportDefinition:
    for report in DEFAULT_REPORTS:
        if report.report_id == report_id:
            return report
    raise KeyError(f"Unknown report: {report_id}")
