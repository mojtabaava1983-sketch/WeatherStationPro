from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any

@dataclass(frozen=True)
class ReportFilter:
    city_id: int | None = None
    start_unix: int | None = None
    end_unix: int | None = None
    source_id: int | None = None

@dataclass(frozen=True)
class ReportColumn:
    name: str
    source_key: str

@dataclass(frozen=True)
class ReportDefinition:
    report_id: str
    title: str
    columns: tuple[ReportColumn, ...]
    description: str = ""

@dataclass
class ReportResult:
    report_id: str
    title: str
    columns: list[str]
    rows: list[dict[str, Any]] = field(default_factory=list)
    generated_utc: str | None = None

    @property
    def row_count(self) -> int:
        return len(self.rows)
