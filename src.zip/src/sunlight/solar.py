from __future__ import annotations
from datetime import date, datetime, timedelta, timezone
from math import acos, asin, atan2, cos, degrees, floor, radians, sin

def _julian_day(day: date) -> float:
    return (day.toordinal() + 1721424.5)

def _sun_event_utc(day: date, latitude: float, longitude: float, zenith: float, sunrise: bool):
    # NOAA-style sunrise/sunset approximation.
    n = day.timetuple().tm_yday
    lng_hour = longitude / 15.0
    t = n + ((6.0 if sunrise else 18.0) - lng_hour) / 24.0

    M = (0.9856 * t) - 3.289
    L = (M + 1.916 * sin(radians(M)) + 0.020 * sin(radians(2 * M)) + 282.634) % 360
    RA = degrees(atan2(0.91764 * sin(radians(L)), cos(radians(L))))
    RA = (RA + 360) % 360
    Lquadrant = floor(L / 90) * 90
    RAquadrant = floor(RA / 90) * 90
    RA = RA + (Lquadrant - RAquadrant)
    RA /= 15.0

    sin_dec = 0.39782 * sin(radians(L))
    cos_dec = cos(asin(sin_dec))

    cos_h = (
        cos(radians(zenith)) -
        sin_dec * sin(radians(latitude))
    ) / (cos_dec * cos(radians(latitude)))

    if cos_h > 1:
        return None, "polar_night"
    if cos_h < -1:
        return None, "polar_day"

    H = degrees(acos(cos_h))
    if not sunrise:
        H = 360 - H
    H /= 15.0

    T = H + RA - 0.06571 * t - 6.622
    UT = (T - lng_hour) % 24

    hours = int(UT)
    minutes_float = (UT - hours) * 60
    minutes = int(minutes_float)
    seconds = int(round((minutes_float - minutes) * 60))

    base = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
    result = base + timedelta(hours=hours, minutes=minutes, seconds=seconds)
    return result, "normal"

def calculate_sun_times(day: date, latitude: float, longitude: float):
    sunrise, sunrise_state = _sun_event_utc(day, latitude, longitude, 90.833, True)
    sunset, sunset_state = _sun_event_utc(day, latitude, longitude, 90.833, False)

    if sunrise is None and sunset is None:
        polar_day = sunrise_state == "polar_day" or sunset_state == "polar_day"
        polar_night = sunrise_state == "polar_night" or sunset_state == "polar_night"
        return sunrise, sunset, None, polar_day, polar_night

    candidates = [x for x in (sunrise, sunset) if x is not None]
    noon = candidates[0] + (candidates[-1] - candidates[0]) / 2 if len(candidates) == 2 else None
    return sunrise, sunset, noon, False, False
