from __future__ import annotations
from dataclasses import dataclass
from datetime import date, datetime

@dataclass(frozen=True)
class SunEvent:
    date: date
    event: str
    timestamp_utc: datetime | None
    solar_noon_utc: datetime | None = None

@dataclass(frozen=True)
class SunTimes:
    date: date
    latitude: float
    longitude: float
    sunrise_utc: datetime | None
    sunset_utc: datetime | None
    solar_noon_utc: datetime | None
    polar_day: bool = False
    polar_night: bool = False
    method: str = "noaa_solar_position"
