class SunlightError(RuntimeError):
    """Base M07 sunlight error."""

class SunlightConfigurationError(SunlightError):
    """Invalid geographic or calculation configuration."""
