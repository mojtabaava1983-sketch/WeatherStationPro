from __future__ import annotations
from datetime import date
from .exceptions import SunlightConfigurationError
from .models import SunTimes
from .solar import calculate_sun_times

class SunlightEngine:
    """Calculates sunrise, sunset and solar noon from coordinates."""

    def __init__(self, *, precision: str = "standard"):
        if precision not in {"standard"}:
            raise SunlightConfigurationError("Unsupported precision.")
        self.precision = precision

    @staticmethod
    def validate_coordinates(latitude: float, longitude: float):
        if not -90 <= latitude <= 90:
            raise SunlightConfigurationError("Latitude must be between -90 and 90.")
        if not -180 <= longitude <= 180:
            raise SunlightConfigurationError("Longitude must be between -180 and 180.")

    def calculate(self, day: date, latitude: float, longitude: float) -> SunTimes:
        self.validate_coordinates(latitude, longitude)
        sunrise, sunset, noon, polar_day, polar_night = calculate_sun_times(
            day, latitude, longitude
        )
        return SunTimes(
            date=day,
            latitude=float(latitude),
            longitude=float(longitude),
            sunrise_utc=sunrise,
            sunset_utc=sunset,
            solar_noon_utc=noon,
            polar_day=polar_day,
            polar_night=polar_night,
        )

    def calculate_range(self, start: date, days: int, latitude: float, longitude: float):
        if days <= 0:
            raise SunlightConfigurationError("days must be greater than zero.")
        return tuple(
            self.calculate(
                start.fromordinal(start.toordinal() + offset),
                latitude,
                longitude,
            )
            for offset in range(days)
        )
