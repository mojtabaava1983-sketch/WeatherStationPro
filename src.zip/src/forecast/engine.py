from __future__ import annotations
from datetime import datetime, timedelta, timezone
from typing import Sequence

from .estimators import ForecastEstimator
from .exceptions import ForecastConfigurationError
from .models import ForecastPoint, ForecastRequest, ForecastSeries

class ForecastEngine:
    """First-generation 1–10 day baseline forecast engine.

    M06 deliberately contains no external API or ML dependency. It consumes
    historical numeric observations and produces a deterministic baseline.
    Provider/model upgrades can be added later without changing the public
    forecast result model.
    """

    def __init__(self, *, default_horizon_days: int = 7, minimum_history: int = 3):
        if not 1 <= default_horizon_days <= 10:
            raise ForecastConfigurationError("default_horizon_days must be between 1 and 10.")
        if minimum_history < 1:
            raise ForecastConfigurationError("minimum_history must be positive.")
        self.default_horizon_days = default_horizon_days
        self.minimum_history = minimum_history

    def forecast(
        self,
        request: ForecastRequest,
        values: Sequence[float | int | None],
        *,
        last_observation_at: datetime,
    ) -> ForecastSeries:
        data = ForecastEstimator.clean(values)
        if len(data) < self.minimum_history:
            raise ForecastConfigurationError(
                f"At least {self.minimum_history} historical values are required."
            )

        steps = self._step_count(request)
        predictions = ForecastEstimator.trend_forecast(data, steps)
        points = []

        for index, prediction in enumerate(predictions, start=1):
            timestamp = last_observation_at + timedelta(hours=request.interval_hours * index)
            spread = ForecastEstimator.uncertainty(data, prediction)
            confidence = max(0.10, 0.90 - (index - 1) * 0.05)
            points.append(
                ForecastPoint(
                    timestamp=timestamp,
                    value=round(prediction, 4) if prediction is not None else None,
                    lower=round(prediction - spread, 4) if prediction is not None else None,
                    upper=round(prediction + spread, 4) if prediction is not None else None,
                    confidence=round(confidence, 3),
                )
            )

        return ForecastSeries(
            city_id=request.city_id,
            field=request.field,
            generated_at=datetime.now(timezone.utc),
            method="linear_trend_baseline",
            points=tuple(points),
            metadata={
                "history_count": len(data),
                "horizon_days": request.horizon_days,
                "interval_hours": request.interval_hours,
                "engine_version": "M06-01",
            },
        )

    def forecast_7_day(self, city_id, field, values, last_observation_at):
        request = ForecastRequest(
            city_id=city_id,
            field=field,
            horizon_days=7,
            interval_hours=24,
        )
        return self.forecast(request, values, last_observation_at=last_observation_at)

    def _step_count(self, request: ForecastRequest) -> int:
        total_hours = request.horizon_days * 24
        return (total_hours + request.interval_hours - 1) // request.interval_hours
