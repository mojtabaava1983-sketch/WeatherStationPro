class ForecastError(RuntimeError):
    """Base M06 forecast error."""

class ForecastConfigurationError(ForecastError):
    """Invalid forecast configuration."""
