from __future__ import annotations
from .models import ForecastSeries

def validate_series(series: ForecastSeries) -> list[str]:
    issues = []
    if not series.points:
        issues.append("Forecast contains no points.")
    previous = None
    for point in series.points:
        if previous is not None and point.timestamp <= previous:
            issues.append("Forecast timestamps are not strictly increasing.")
            break
        previous = point.timestamp
        if point.value is not None and point.lower is not None and point.upper is not None:
            if point.lower > point.value or point.value > point.upper:
                issues.append("Forecast interval does not contain forecast value.")
                break
    return issues
