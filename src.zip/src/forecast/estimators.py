from __future__ import annotations
from math import sqrt
from statistics import mean

class ForecastEstimator:
    """Dependency-free baseline estimators for the first M06 implementation."""

    @staticmethod
    def clean(values):
        return [float(v) for v in values if v is not None]

    @classmethod
    def last_value(cls, values):
        data = cls.clean(values)
        return data[-1] if data else None

    @classmethod
    def moving_average(cls, values, window=5):
        data = cls.clean(values)
        if not data:
            return None
        return mean(data[-window:])

    @classmethod
    def linear_trend(cls, values):
        data = cls.clean(values)
        if len(data) < 2:
            return 0.0
        xs = list(range(len(data)))
        xm = mean(xs)
        ym = mean(data)
        denominator = sum((x - xm) ** 2 for x in xs)
        if denominator == 0:
            return 0.0
        return sum((x - xm) * (y - ym) for x, y in zip(xs, data)) / denominator

    @classmethod
    def trend_forecast(cls, values, steps):
        data = cls.clean(values)
        if not data:
            return [None] * steps
        slope = cls.linear_trend(data)
        intercept = data[-1] - slope * (len(data) - 1)
        return [intercept + slope * (len(data) + i) for i in range(steps)]

    @classmethod
    def uncertainty(cls, values, forecast):
        data = cls.clean(values)
        if len(data) < 2:
            spread = max(abs(forecast) * 0.05, 1.0)
            return spread
        avg = mean(data)
        variance = sum((x - avg) ** 2 for x in data) / len(data)
        return max(sqrt(variance), abs(forecast) * 0.02, 0.1)
