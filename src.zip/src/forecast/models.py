from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

@dataclass(frozen=True)
class ForecastRequest:
    city_id: int | None
    field: str
    horizon_days: int = 7
    interval_hours: int = 24
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if not 1 <= self.horizon_days <= 10:
            raise ValueError("horizon_days must be between 1 and 10.")
        if self.interval_hours <= 0:
            raise ValueError("interval_hours must be greater than zero.")
        if not self.field.strip():
            raise ValueError("Forecast field cannot be empty.")

@dataclass(frozen=True)
class ForecastPoint:
    timestamp: datetime
    value: float | None
    lower: float | None = None
    upper: float | None = None
    confidence: float | None = None

@dataclass(frozen=True)
class ForecastSeries:
    city_id: int | None
    field: str
    generated_at: datetime
    method: str
    points: tuple[ForecastPoint, ...]
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def values(self) -> tuple[float | None, ...]:
        return tuple(point.value for point in self.points)
