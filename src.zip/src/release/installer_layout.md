# Installer Layout

Recommended Windows deployment:

WeatherStation Pro/
├── app/
├── config/
├── data/
├── backups/
├── logs/
└── docs/

Rules:

- Application code is installed under `app`.
- Configuration is separate from application code.
- Database files belong under `data`.
- Backups belong under `backups`.
- Runtime logs belong under `logs`.
- User-editable configuration must not be overwritten blindly during upgrade.

## Upgrade

1. Stop application services.
2. Create a safety backup through M10.
3. Install the new application package.
4. Preserve user configuration and database.
5. Run release health checks.
6. Start the application.
7. If validation fails, restore the previous application package and database
   according to the rollback procedure.

## Rollback

Rollback is explicit and never automatic destruction of user data.
