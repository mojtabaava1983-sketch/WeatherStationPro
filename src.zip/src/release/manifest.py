from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable

@dataclass(frozen=True)
class ModuleEntry:
    module_id: str
    name: str
    version: str
    required: bool = True

@dataclass(frozen=True)
class ReleaseManifest:
    application: str
    version: str
    channel: str
    modules: tuple[ModuleEntry, ...]

    def validate(self) -> list[str]:
        errors: list[str] = []
        if not self.application.strip():
            errors.append("Application name is required.")
        if not self.version.strip():
            errors.append("Application version is required.")
        if not self.modules:
            errors.append("At least one module is required.")

        ids = [item.module_id for item in self.modules]
        if len(ids) != len(set(ids)):
            errors.append("Duplicate module IDs exist.")

        return errors
