from .manifest import ModuleEntry, ReleaseManifest
from .version import APP_NAME, APP_VERSION, RELEASE_CHANNEL

MODULES = tuple(
    ModuleEntry(f"M{i:02d}", name, "1.0.0")
    for i, name in (
        (1, "Database Core"),
        (2, "Configuration & Settings"),
        (3, "Weather API Engine"),
        (4, "Scheduler"),
        (5, "Data Analysis Engine"),
        (6, "Forecast Engine"),
        (7, "Sunrise / Sunset Engine"),
        (8, "Microsoft Access Interface"),
        (9, "Reporting & Export"),
        (10, "Backup & Recovery"),
        (11, "Plugin System"),
        (12, "Installer & Release"),
    )
)

DEFAULT_MANIFEST = ReleaseManifest(
    application=APP_NAME,
    version=APP_VERSION,
    channel=RELEASE_CHANNEL,
    modules=MODULES,
)
