from __future__ import annotations
import hashlib
from pathlib import Path

def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()

def write_checksum_file(
    artifact: str | Path,
    output: str | Path | None = None,
) -> Path:
    artifact_path = Path(artifact)
    output_path = (
        Path(output)
        if output is not None
        else artifact_path.with_suffix(artifact_path.suffix + ".sha256")
    )
    output_path.write_text(
        f"{sha256_file(artifact_path)}  {artifact_path.name}\n",
        encoding="utf-8",
    )
    return output_path
