from __future__ import annotations
import zipfile
from pathlib import Path

class PackagingError(RuntimeError):
    pass

def build_zip(source_dir: str | Path, output: str | Path) -> Path:
    source = Path(source_dir)
    destination = Path(output)

    if not source.exists() or not source.is_dir():
        raise PackagingError(f"Source directory not found: {source}")

    destination.parent.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(
        destination,
        "w",
        compression=zipfile.ZIP_DEFLATED,
    ) as archive:
        for path in source.rglob("*"):
            if path.is_file():
                archive.write(path, path.relative_to(source))

    return destination
