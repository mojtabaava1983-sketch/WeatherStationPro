﻿APP_NAME = "WeatherStation Pro"
APP_VERSION = "0.1.0"
RELEASE_CHANNEL = "stable"

def version_string() -> str:
    return f"{APP_NAME} {APP_VERSION}"

