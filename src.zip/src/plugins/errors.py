class PluginError(RuntimeError):
    pass

class PluginValidationError(PluginError):
    pass

class DuplicatePluginError(PluginError):
    pass

class IncompatiblePluginError(PluginError):
    pass
