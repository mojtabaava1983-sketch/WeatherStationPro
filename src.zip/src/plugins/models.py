from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Mapping

@dataclass(frozen=True)
class PluginInfo:
    plugin_id: str
    name: str
    version: str
    api_version: str
    capabilities: tuple[str, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)

@dataclass
class PluginContext:
    application_name: str = "WeatherStation Pro"
    application_version: str = "0.1"
    services: dict[str, Any] = field(default_factory=dict)
