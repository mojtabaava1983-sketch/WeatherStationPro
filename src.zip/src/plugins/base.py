from __future__ import annotations
from abc import ABC, abstractmethod
from .models import PluginContext, PluginInfo

class Plugin(ABC):
    @property
    @abstractmethod
    def info(self) -> PluginInfo:
        raise NotImplementedError

    def initialize(self, context: PluginContext) -> None:
        pass

    def start(self) -> None:
        pass

    def stop(self) -> None:
        pass

    def shutdown(self) -> None:
        pass
