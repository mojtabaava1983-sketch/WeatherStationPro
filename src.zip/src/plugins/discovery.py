from __future__ import annotations
import importlib
from collections.abc import Iterable
from .base import Plugin

def load_plugin_factories(
    module_names: Iterable[str],
) -> list[Plugin]:
    plugins: list[Plugin] = []

    for module_name in module_names:
        module = importlib.import_module(module_name)
        factory = getattr(module, "create_plugin", None)
        if factory is None:
            raise AttributeError(
                f"Plugin module {module_name!r} has no create_plugin()"
            )
        plugin = factory()
        if not isinstance(plugin, Plugin):
            raise TypeError(
                f"Plugin module {module_name!r} returned an invalid plugin."
            )
        plugins.append(plugin)

    return plugins
