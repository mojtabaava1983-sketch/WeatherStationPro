from __future__ import annotations
from collections.abc import Iterable
from .base import Plugin
from .errors import (
    DuplicatePluginError,
    IncompatiblePluginError,
    PluginValidationError,
)
from .models import PluginContext

class PluginRegistry:
    def __init__(self, api_version: str = "1"):
        self.api_version = api_version
        self._plugins: dict[str, Plugin] = {}

    def register(self, plugin: Plugin) -> None:
        info = plugin.info

        if not info.plugin_id.strip():
            raise PluginValidationError("Plugin ID is required.")
        if not info.name.strip():
            raise PluginValidationError("Plugin name is required.")
        if info.plugin_id in self._plugins:
            raise DuplicatePluginError(info.plugin_id)
        if info.api_version != self.api_version:
            raise IncompatiblePluginError(
                f"{info.plugin_id}: API {info.api_version} != {self.api_version}"
            )

        self._plugins[info.plugin_id] = plugin

    def register_many(self, plugins: Iterable[Plugin]) -> None:
        for plugin in plugins:
            self.register(plugin)

    def get(self, plugin_id: str) -> Plugin | None:
        return self._plugins.get(plugin_id)

    def list_info(self):
        return tuple(plugin.info for plugin in self._plugins.values())

    def initialize_all(self, context: PluginContext) -> None:
        for plugin in self._plugins.values():
            plugin.initialize(context)

    def start_all(self) -> None:
        for plugin in self._plugins.values():
            plugin.start()

    def stop_all(self) -> None:
        for plugin in reversed(tuple(self._plugins.values())):
            plugin.stop()

    def shutdown_all(self) -> None:
        for plugin in reversed(tuple(self._plugins.values())):
            plugin.shutdown()
