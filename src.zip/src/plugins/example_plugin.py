from .base import Plugin
from .models import PluginContext, PluginInfo

class ExamplePlugin(Plugin):
    @property
    def info(self) -> PluginInfo:
        return PluginInfo(
            plugin_id="example.plugin",
            name="Example Plugin",
            version="1.0.0",
            api_version="1",
            capabilities=("example",),
        )

    def initialize(self, context: PluginContext) -> None:
        context.services["example.plugin"] = {"initialized": True}

def create_plugin() -> Plugin:
    return ExamplePlugin()
