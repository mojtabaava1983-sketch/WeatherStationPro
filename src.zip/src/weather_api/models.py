from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Mapping

@dataclass(frozen=True)
class ApiRequest:
    url: str
    method: str = "GET"
    params: Mapping[str, Any] = field(default_factory=dict)
    headers: Mapping[str, str] = field(default_factory=dict)
    timeout: float = 10.0

@dataclass(frozen=True)
class ProviderResponse:
    provider: str
    status_code: int
    data: Mapping[str, Any]
    url: str

@dataclass(frozen=True)
class NormalizedObservation:
    temperature: Any = None
    humidity: Any = None
    wind_speed: Any = None
    pressure: Any = None
    precipitation: Any = None
    cloud_cover: Any = None
    visibility: Any = None
    uv_index: Any = None
    weather_description: Any = None
    sunrise: Any = None
    sunset: Any = None
    observed_utc: Any = None
    extras: Mapping[str, Any] = field(default_factory=dict)
    def to_dict(self):
        return {
            "Temperature": self.temperature, "Humidity": self.humidity,
            "WindSpeed": self.wind_speed, "Pressure": self.pressure,
            "Precipitation": self.precipitation, "CloudCover": self.cloud_cover,
            "Visibility": self.visibility, "UVIndex": self.uv_index,
            "WeatherDescription": self.weather_description,
            "Sunrise": self.sunrise, "Sunset": self.sunset,
            "ObservedUTC": self.observed_utc, **dict(self.extras),
        }

@dataclass(frozen=True)
class ApiResult:
    provider: str
    observation: NormalizedObservation | None
    status_code: int
    attempts: int
    error: str | None = None
