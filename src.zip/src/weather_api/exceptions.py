class WeatherApiError(RuntimeError): pass
class ApiConfigurationError(WeatherApiError): pass
class ApiRequestError(WeatherApiError): pass
class ApiResponseError(WeatherApiError): pass
class RetryExhaustedError(ApiRequestError): pass
