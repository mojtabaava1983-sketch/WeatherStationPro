from __future__ import annotations
from typing import Mapping, Any
from .client import HttpClient
from .exceptions import ApiConfigurationError, ApiResponseError
from .models import ApiResult, ProviderResponse

class WeatherApiEngine:
    def __init__(self, provider, client=None):
        self.provider = provider
        self.client = client or HttpClient()
    def fetch(self, location: Mapping[str, Any]) -> ApiResult:
        try: request = self.provider.build_request(location)
        except Exception as exc: raise ApiConfigurationError("Provider request construction failed.") from exc
        response, attempts = self.client.request(request)
        if not 200 <= response.status_code < 300:
            raise ApiResponseError(f"Unexpected HTTP status: {response.status_code}")
        observation = self.provider.normalize(ProviderResponse(self.provider.name, response.status_code, response.data, response.url))
        return ApiResult(self.provider.name, observation, response.status_code, attempts)
