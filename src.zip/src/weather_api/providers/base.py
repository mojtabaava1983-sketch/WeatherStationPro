from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Any, Mapping
from ..models import NormalizedObservation

class WeatherProvider(ABC):
    name = "unknown"
    @abstractmethod
    def build_request(self, location: Mapping[str, Any]): ...
    @abstractmethod
    def normalize(self, response): ...
