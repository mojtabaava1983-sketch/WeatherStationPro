﻿from __future__ import annotations

from typing import Any, Mapping

from ..models import ApiRequest, NormalizedObservation, ProviderResponse
from .base import WeatherProvider


class OpenMeteoProvider(WeatherProvider):
    name = "open-meteo"

    BASE_URL = "https://api.open-meteo.com/v1/forecast"

    CURRENT_FIELDS = (
        "temperature_2m,"
        "relative_humidity_2m,"
        "apparent_temperature,"
        "precipitation,"
        "rain,"
        "showers,"
        "snowfall,"
        "weather_code,"
        "cloud_cover,"
        "surface_pressure,"
        "wind_speed_10m,"
        "wind_direction_10m,"
        "wind_gusts_10m"
    )

    def build_request(self, location: Mapping[str, Any]) -> ApiRequest:
        if "latitude" not in location or "longitude" not in location:
            raise ValueError("latitude and longitude are required.")

        latitude = float(location["latitude"])
        longitude = float(location["longitude"])

        if not -90 <= latitude <= 90:
            raise ValueError("latitude must be between -90 and 90.")

        if not -180 <= longitude <= 180:
            raise ValueError("longitude must be between -180 and 180.")

        params = {
            "latitude": latitude,
            "longitude": longitude,
            "current": self.CURRENT_FIELDS,
            "timezone": "UTC",
            "temperature_unit": "celsius",
            "wind_speed_unit": "kmh",
            "precipitation_unit": "mm",
        }

        return ApiRequest(
            url=self.BASE_URL,
            method="GET",
            params=params,
            timeout=15.0,
        )

    def normalize(self, response: ProviderResponse) -> NormalizedObservation:
        current = response.data.get("current")

        if not isinstance(current, Mapping):
            raise ValueError("Open-Meteo response does not contain current data.")

        return NormalizedObservation(
            temperature=current.get("temperature_2m"),
            humidity=current.get("relative_humidity_2m"),
            wind_speed=current.get("wind_speed_10m"),
            pressure=current.get("surface_pressure"),
            precipitation=current.get("precipitation"),
            cloud_cover=current.get("cloud_cover"),
            visibility=None,
            uv_index=None,
            weather_description=current.get("weather_code"),
            sunrise=None,
            sunset=None,
            observed_utc=current.get("time"),
            extras={
                "ApparentTemperature": current.get("apparent_temperature"),
                "Rain": current.get("rain"),
                "Showers": current.get("showers"),
                "Snowfall": current.get("snowfall"),
                "WindDirection": current.get("wind_direction_10m"),
                "WindGusts": current.get("wind_gusts_10m"),
                "Latitude": response.data.get("latitude"),
                "Longitude": response.data.get("longitude"),
                "Timezone": response.data.get("timezone"),
                "WeatherCode": current.get("weather_code"),
            },
        )
