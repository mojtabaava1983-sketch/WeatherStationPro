from __future__ import annotations
import json
from dataclasses import dataclass
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from .exceptions import ApiRequestError, ApiResponseError
from .models import ApiRequest
from .retry import RetryPolicy

@dataclass(frozen=True)
class HttpResponse:
    status_code: int
    url: str
    data: dict

class HttpClient:
    def __init__(self, retry_policy=None):
        self.retry_policy = retry_policy or RetryPolicy()
    @staticmethod
    def _retryable(exc):
        return (isinstance(exc, HTTPError) and exc.code in {408,425,429,500,502,503,504}) or isinstance(exc, (URLError, TimeoutError))
    def request(self, request: ApiRequest):
        if request.method.upper() != "GET":
            raise ApiRequestError("Only GET is supported by M03.")
        url = request.url
        if request.params:
            url += ("&" if "?" in url else "?") + urlencode(request.params, doseq=True)
        req = Request(url, headers=dict(request.headers), method="GET")
        def operation():
            try:
                with urlopen(req, timeout=request.timeout) as response:
                    raw = response.read()
                    try: data = json.loads(raw.decode("utf-8"))
                    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                        raise ApiResponseError("Response is not valid JSON.") from exc
                    if not isinstance(data, dict): raise ApiResponseError("JSON response must be an object.")
                    return HttpResponse(int(response.status), response.geturl(), data)
            except HTTPError as exc:
                raise ApiResponseError(f"HTTP {exc.code} from weather provider.") from exc
            except (URLError, TimeoutError, OSError) as exc:
                raise ApiRequestError("Weather API request failed.") from exc
        return self.retry_policy.run(operation, self._retryable)
