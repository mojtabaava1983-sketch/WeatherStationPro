from __future__ import annotations
import time
from dataclasses import dataclass
from typing import Callable, TypeVar
T = TypeVar("T")

@dataclass(frozen=True)
class RetryPolicy:
    max_attempts: int = 3
    backoff_seconds: float = 0.25
    def __post_init__(self):
        if self.max_attempts < 1: raise ValueError("max_attempts must be >= 1")
        if self.backoff_seconds < 0: raise ValueError("backoff_seconds must be >= 0")
    def run(self, operation: Callable[[], T], should_retry: Callable[[Exception], bool]):
        for attempt in range(1, self.max_attempts + 1):
            try: return operation(), attempt
            except Exception as exc:
                if attempt >= self.max_attempts or not should_retry(exc): raise
                delay = self.backoff_seconds * (2 ** (attempt - 1))
                if delay: time.sleep(delay)
