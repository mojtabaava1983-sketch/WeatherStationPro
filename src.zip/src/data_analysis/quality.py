from __future__ import annotations
from .models import Observation

def quality_score(observation: Observation) -> float:
    """Return a bounded quality score without altering the observation."""
    return max(0.0, min(100.0, float(observation.quality)))

def acceptable(observation: Observation, minimum: float = 0.0) -> bool:
    return quality_score(observation) >= minimum
