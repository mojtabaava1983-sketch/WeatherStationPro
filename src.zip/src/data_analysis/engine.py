from __future__ import annotations
from datetime import datetime
from typing import Iterable, Sequence

from .exceptions import AnalysisConfigurationError
from .models import AnalysisResult, AnalysisSummary, Observation, TrendResult
from .statistics import StatisticsCalculator

class DataAnalysisEngine:
    """Pure analysis layer for normalized weather observations."""

    def __init__(self, *, minimum_quality: float = 0.0):
        if not 0 <= minimum_quality <= 100:
            raise AnalysisConfigurationError("minimum_quality must be between 0 and 100.")
        self.minimum_quality = minimum_quality

    def filter_quality(self, observations: Iterable[Observation]) -> list[Observation]:
        return [o for o in observations if o.quality >= self.minimum_quality]

    def analyze_field(self, observations: Sequence[Observation], field: str) -> AnalysisResult:
        values = [o.value(field) for o in observations]
        clean = StatisticsCalculator.clean(values)
        return AnalysisResult(
            field=field,
            count=len(clean),
            minimum=StatisticsCalculator.minimum(values),
            maximum=StatisticsCalculator.maximum(values),
            mean=StatisticsCalculator.mean(values),
            median=StatisticsCalculator.median(values),
            standard_deviation=StatisticsCalculator.population_stddev(values),
            first=clean[0] if clean else None,
            last=clean[-1] if clean else None,
            missing=len(values) - len(clean),
        )

    def trend(self, observations: Sequence[Observation], field: str) -> TrendResult:
        valid = [(o.observed_at, o.value(field)) for o in observations if o.value(field) is not None]
        if len(valid) < 2:
            return TrendResult(field, None, "insufficient_data", None, len(valid))
        start = valid[0][0]
        xs = [(ts - start).total_seconds() for ts, _ in valid]
        ys = [value for _, value in valid]
        slope = StatisticsCalculator.linear_slope(xs, ys)
        change = ys[-1] - ys[0]
        if abs(change) < 1e-12:
            direction = "stable"
        elif change > 0:
            direction = "rising"
        else:
            direction = "falling"
        return TrendResult(field, slope, direction, change, len(valid))

    def summarize(
        self,
        observations: Iterable[Observation],
        fields: Sequence[str],
    ) -> AnalysisSummary:
        data = sorted(self.filter_quality(observations), key=lambda o: o.observed_at)
        results = tuple(self.analyze_field(data, f) for f in fields)
        trends = tuple(self.trend(data, f) for f in fields)
        metadata = {
            "observation_count": len(data),
            "fields": tuple(fields),
            "minimum_quality": self.minimum_quality,
        }
        return AnalysisSummary(results, trends, metadata)

    @staticmethod
    def rolling_mean(
        observations: Sequence[Observation],
        field: str,
        window: int,
    ) -> list[tuple[datetime, float]]:
        if window <= 0:
            raise AnalysisConfigurationError("window must be greater than zero.")
        valid = [(o.observed_at, o.value(field)) for o in observations]
        valid = [(ts, value) for ts, value in valid if value is not None]
        output = []
        for index in range(window - 1, len(valid)):
            chunk = [value for _, value in valid[index-window+1:index+1]]
            output.append((valid[index][0], sum(chunk) / len(chunk)))
        return output
