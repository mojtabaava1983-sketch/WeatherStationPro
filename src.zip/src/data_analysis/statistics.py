from __future__ import annotations
from math import sqrt
from statistics import median
from typing import Iterable

class StatisticsCalculator:
    @staticmethod
    def clean(values: Iterable[float | int | None]) -> list[float]:
        return [float(v) for v in values if v is not None]

    @classmethod
    def mean(cls, values):
        data = cls.clean(values)
        return sum(data) / len(data) if data else None

    @classmethod
    def median(cls, values):
        data = cls.clean(values)
        return median(data) if data else None

    @classmethod
    def minimum(cls, values):
        data = cls.clean(values)
        return min(data) if data else None

    @classmethod
    def maximum(cls, values):
        data = cls.clean(values)
        return max(data) if data else None

    @classmethod
    def population_stddev(cls, values):
        data = cls.clean(values)
        if not data:
            return None
        avg = sum(data) / len(data)
        return sqrt(sum((x - avg) ** 2 for x in data) / len(data))

    @classmethod
    def linear_slope(cls, xs, ys):
        pairs = [(float(x), float(y)) for x, y in zip(xs, ys) if y is not None]
        if len(pairs) < 2:
            return None
        xm = sum(x for x, _ in pairs) / len(pairs)
        ym = sum(y for _, y in pairs) / len(pairs)
        denominator = sum((x - xm) ** 2 for x, _ in pairs)
        if denominator == 0:
            return 0.0
        return sum((x - xm) * (y - ym) for x, y in pairs) / denominator
