class AnalysisError(RuntimeError):
    """Base M05 analysis error."""

class AnalysisConfigurationError(AnalysisError):
    """Invalid analysis configuration."""
