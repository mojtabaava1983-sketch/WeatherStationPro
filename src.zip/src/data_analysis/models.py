from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

@dataclass(frozen=True)
class Observation:
    observed_at: datetime
    values: dict[str, float | int | None]
    city_id: int | None = None
    source_id: int | None = None
    quality: float = 100.0

    def value(self, field: str) -> float | None:
        value = self.values.get(field)
        return float(value) if value is not None else None

@dataclass(frozen=True)
class AnalysisResult:
    field: str
    count: int
    minimum: float | None
    maximum: float | None
    mean: float | None
    median: float | None
    standard_deviation: float | None
    first: float | None
    last: float | None
    missing: int

@dataclass(frozen=True)
class TrendResult:
    field: str
    slope_per_second: float | None
    direction: str
    change: float | None
    sample_count: int

@dataclass(frozen=True)
class WindowPoint:
    timestamp: datetime
    value: float

@dataclass(frozen=True)
class AnalysisSummary:
    results: tuple[AnalysisResult, ...]
    trends: tuple[TrendResult, ...]
    metadata: dict[str, Any] = field(default_factory=dict)
