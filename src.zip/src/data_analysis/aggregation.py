from __future__ import annotations
from collections import defaultdict
from datetime import datetime
from typing import Sequence
from .models import Observation
from .statistics import StatisticsCalculator

class ObservationAggregator:
    """Simple time-bucket aggregation for weather observations."""

    @staticmethod
    def by_hour(observations: Sequence[Observation], field: str):
        buckets = defaultdict(list)
        for observation in observations:
            value = observation.value(field)
            if value is not None:
                key = observation.observed_at.replace(minute=0, second=0, microsecond=0)
                buckets[key].append(value)
        return {
            timestamp: {
                "count": len(values),
                "mean": StatisticsCalculator.mean(values),
                "minimum": StatisticsCalculator.minimum(values),
                "maximum": StatisticsCalculator.maximum(values),
            }
            for timestamp, values in sorted(buckets.items())
        }
