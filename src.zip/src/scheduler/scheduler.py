from __future__ import annotations
import logging
import threading
from datetime import datetime
from .clock import Clock
from .exceptions import SchedulerConfigurationError
from .models import Job, JobResult

class Scheduler:
    def __init__(self, *, clock=None, logger=None):
        self.clock=clock or Clock()
        self.logger=logger or logging.getLogger("weatherstation.scheduler")
        self._jobs={}
        self._lock=threading.RLock()
        self._running=False

    def add_job(self, job):
        with self._lock:
            if job.name in self._jobs:
                raise SchedulerConfigurationError(f"Job already exists: {job.name}")
            now=self.clock.now()
            job.next_run=now if job.run_immediately else now+job.schedule.interval
            self._jobs[job.name]=job

    def add_jobs(self, jobs):
        for job in jobs: self.add_job(job)

    def remove_job(self, name):
        with self._lock: return self._jobs.pop(name, None) is not None

    def get_job(self, name):
        with self._lock: return self._jobs.get(name)

    def list_jobs(self):
        with self._lock: return tuple(self._jobs.values())

    def start(self):
        with self._lock: self._running=True

    def stop(self):
        with self._lock: self._running=False

    @property
    def running(self): return self._running

    def due_jobs(self, now=None):
        current=now or self.clock.now()
        with self._lock:
            return tuple(j for j in self._jobs.values()
                         if j.enabled and j.next_run is not None and j.next_run <= current)

    def run_due(self, now=None):
        current=now or self.clock.now()
        return [self._run_job(j,current) for j in self.due_jobs(current)]

    def tick(self, now=None):
        if not self.running: return []
        return self.run_due(now)

    def _run_job(self, job, scheduled_at):
        started=self.clock.now()
        try:
            value=job.callback()
            result=JobResult(job.name, started, self.clock.now(), True, value, None)
        except Exception as exc:
            self.logger.exception("Scheduled job failed: %s", job.name)
            result=JobResult(job.name, started, self.clock.now(), False, None, str(exc))
        with self._lock:
            job.next_run=scheduled_at+job.schedule.interval
        return result

    def next_wake_time(self):
        with self._lock:
            values=[j.next_run for j in self._jobs.values() if j.enabled and j.next_run]
        return min(values) if values else None
