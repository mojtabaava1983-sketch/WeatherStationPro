from datetime import datetime, timezone
class Clock:
    def now(self): return datetime.now(timezone.utc)
class FixedClock(Clock):
    def __init__(self, value): self.value=value
    def now(self): return self.value
    def set(self, value): self.value=value
