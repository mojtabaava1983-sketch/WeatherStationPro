from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Callable

@dataclass(frozen=True)
class Schedule:
    interval: timedelta
    def __post_init__(self):
        if self.interval.total_seconds() <= 0:
            raise ValueError("Schedule interval must be greater than zero.")
    @classmethod
    def seconds(cls, value): return cls(timedelta(seconds=value))
    @classmethod
    def minutes(cls, value): return cls(timedelta(minutes=value))
    @classmethod
    def hours(cls, value): return cls(timedelta(hours=value))

@dataclass
class Job:
    name: str
    callback: Callable[[], Any]
    schedule: Schedule
    enabled: bool = True
    run_immediately: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)
    next_run: datetime | None = None
    def __post_init__(self):
        if not self.name.strip(): raise ValueError("Job name cannot be empty.")
        if not callable(self.callback): raise TypeError("Job callback must be callable.")

@dataclass(frozen=True)
class JobResult:
    job_name: str
    started_at: datetime
    finished_at: datetime
    success: bool
    value: Any = None
    error: str | None = None
    @property
    def duration_seconds(self): return (self.finished_at-self.started_at).total_seconds()
