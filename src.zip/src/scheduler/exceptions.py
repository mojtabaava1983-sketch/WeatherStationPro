class SchedulerError(RuntimeError):
    pass
class SchedulerConfigurationError(SchedulerError):
    pass
class JobExecutionError(SchedulerError):
    pass
