import threading
class SchedulerRunner:
    def __init__(self, scheduler, poll_interval=1.0):
        if poll_interval <= 0: raise ValueError("poll_interval must be greater than zero.")
        self.scheduler=scheduler
        self.poll_interval=poll_interval
        self._stop=threading.Event()
    def stop(self): self._stop.set()
    def run(self):
        self.scheduler.start()
        while not self._stop.is_set():
            self.scheduler.tick()
            self._stop.wait(self.poll_interval)
        self.scheduler.stop()
